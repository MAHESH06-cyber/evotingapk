package com.pgames.evoting.fragment.voter;

import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.adapter.ElectionListAdapter;
import com.pgames.evoting.adapter.ScheduleAdapter;
import com.pgames.evoting.fragment.common.Blocked;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.ElectionList;

import org.w3c.dom.Text;

import java.util.Map;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link UpcommingElections#newInstance} factory method to
 * create an instance of this fragment.
 */
public class UpcommingElections extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private ElectionListAdapter adapter;
    private DataFire dataFire;
    private TextView mInfo;

    public UpcommingElections() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment UpcommingElections.
     */
    // TODO: Rename and change types and number of parameters
    public static UpcommingElections newInstance(String param1, String param2) {
        UpcommingElections fragment = new UpcommingElections();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                System.exit(0);
            }
        };

        getActivity().getOnBackPressedDispatcher().addCallback(onBackPressedCallback);
        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcomming_elections, container, false);
        //initialize
        widget(view);

        if (dataFire.getUser() != null)
            if (getContext() != null)
                dataFire.getUserRef().child("status").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            try {
                                if (snapshot.getValue().toString().equals("blocked")) {
                                    Log.e("User", snapshot.getValue().toString());
                                    Objects.requireNonNull(getActivity()).getSupportFragmentManager()
                                            .beginTransaction()
                                            .replace(R.id.main_host_fragment, new Blocked())
                                            .commit();
                                }
                            } catch (NullPointerException pointerException) {
                                pointerException.printStackTrace();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.e("Deveice Id", "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        String token = task.getResult().getToken();
                        dataFire.getApplyingRef().child(token).setValue("registered");
                        Log.e("Device Id", token);

                    }
                });

        updateUI();
        ((MainActivity) Objects.requireNonNull(getActivity())).showBottomNavBar();
        return view;
    }

    private void widget(View view) {
        Toolbar toolbar = view.findViewById(R.id.tool_upcoming_election);
        TextView textView = view.findViewById(R.id.txt_toolbar_title);
        textView.setText(R.string.upcoming_elections);
        ImageView back = view.findViewById(R.id.img_btn_toolbar_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) Objects.requireNonNull(getActivity())).onBackPressed();
            }
        });
        back.setVisibility(View.INVISIBLE);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_upcoming);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        mInfo = (TextView) view.findViewById(R.id.txt_ele_info);
    }

    private void updateUI() {
        if (dataFire.getUser() != null) {
            Query query = dataFire.getScheduleRef();
            FirebaseRecyclerOptions<ElectionList> options = new FirebaseRecyclerOptions.Builder<ElectionList>()
                    .setQuery(query, ElectionList.class)
                    .build();
            adapter = new ElectionListAdapter(options, getContext());
            recyclerView.setAdapter(adapter);
            if (getContext() != null)
                query.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        try {
                            if (snapshot.exists()) {
                                mInfo.setVisibility(View.GONE);
                            } else {
                                mInfo.setVisibility(View.VISIBLE);
//                            mInfo.setText("Schedule not set by admin");
                                mInfo.setText(getString(R.string.upcomming_ele_info));
                            }
                        } catch (IllegalStateException illegalStateException) {
                            Log.e("Upcomming exp", illegalStateException.getMessage());
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}