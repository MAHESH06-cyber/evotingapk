package com.pgames.evoting.fragment.candidate;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.common.AboutProfile;
import com.pgames.evoting.fragment.common.Blocked;
import com.pgames.evoting.fragment.common.LoadCandidateProfile;
import com.pgames.evoting.fragment.voter.CandidateDetails;
import com.pgames.evoting.models.DataFire;

import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CandidateProfile#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CandidateProfile extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String ARG_PROFILE_PIC = "profile";
    private static final String ARG_NAME = "name";
    private static final String ARG_EMAIL = "email";
    private static final String ARG_CONTACT = "contact";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";

    private final static String ARG_ABOUT = "about";
    private final static String ARG_ACHIEVEMENT = "achievements";
    private final static String ARG_ELECTION = "election";



    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private RadioButton mPersonalInfo, mNominationInfo;
    private ImageView mProfilePhoto;
    private String mParamProfile;
    private LoadCandidateProfile  loadCandidateProfile;
    private AboutProfile aboutProfile;
    private String mParamName;
    private String mParamEmail;
    private String mParamContact;
    private String mParamYear;
    private String mParamDept;
    public CandidateProfile() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CandidateProfile.
     */
    // TODO: Rename and change types and number of parameters
    public static CandidateProfile newInstance(String param1, String param2) {
        CandidateProfile fragment = new CandidateProfile();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            mParamProfile = getArguments().getString(ARG_PROFILE_PIC);
            mParamName = getArguments().getString(ARG_NAME);
            mParamContact = getArguments().getString(ARG_CONTACT);
            mParamEmail = getArguments().getString(ARG_EMAIL);
            mParamDept = getArguments().getString(ARG_DEPT);
            mParamYear = getArguments().getString(ARG_YEAR);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_candidate_profile, container, false);
        //initialization
        widget(view);
        listner();
        DataFire dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
        if (dataFire.getUser() != null)
            dataFire.getUserRef().child("status").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        try {
                            if (snapshot.getValue().toString().equals("blocked")) {
                                Log.e("User", snapshot.getValue().toString());
                                Objects.requireNonNull(getActivity()).getSupportFragmentManager()
                                        .beginTransaction()
                                        .replace(R.id.main_host_fragment, new Blocked())
                                        .commit();
                            }
                        }catch (NullPointerException pointerException){
                            Log.e("Blocked Exp",pointerException.getMessage());
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        Glide.with(Objects.requireNonNull(getContext())).load(mParamProfile).into(mProfilePhoto);
        Objects.requireNonNull(getActivity()).getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.host_fragment_profile, loadCandidateProfile)
                .commit();
        return view;
    }


    private void listner() {


        mPersonalInfo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                   startFragment(loadCandidateProfile);
                }
            }
        });

        mNominationInfo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    startFragment(aboutProfile);
                }
            }
        });

    }

    private void startFragment(Fragment fragment) {
        Objects.requireNonNull(getActivity()).getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.host_fragment_profile,fragment)
                .commit();
    }

    private void widget(View view) {
        Toolbar toolbar  = view.findViewById(R.id.tool_profile_candiate);
        TextView title = view.findViewById(R.id.txt_toolbar_title);
        title.setText(getString(R.string.candidate_profile));
//        ImageView save = view.findViewById(R.id.img_btn_toolbar_save);
//        ImageView close = view.findViewById(R.id.img_btn_toolbar_close);
//        save.setVisibility(View.INVISIBLE);
//        close.setVisibility(View.INVISIBLE);

        loadCandidateProfile = new LoadCandidateProfile();
        profileBundle =  new Bundle();
        profileBundle.putString(ARG_NAME,mParamName);
        profileBundle.putString(ARG_EMAIL,mParamEmail);
        profileBundle.putString(ARG_CONTACT,mParamContact);
        profileBundle.putString(ARG_DEPT,mParamDept);
        profileBundle.putString(ARG_YEAR,mParamYear);
        loadCandidateProfile.setArguments(profileBundle);

        aboutProfile =new AboutProfile();
        aboutBundle = new Bundle();
        getData();
        aboutProfile.setArguments(aboutBundle);


        //ImageView
        mProfilePhoto = (ImageView) view.findViewById(R.id.resultImage);

        //Radio buttons
        mPersonalInfo = (RadioButton) view.findViewById(R.id.rdb_personal_info);
        mNominationInfo = (RadioButton) view.findViewById(R.id.rdb_nomination_info);
    }
    Bundle aboutBundle;
    Bundle profileBundle;
    private void getData(){
        DataFire dataFire = new DataFire();
        dataFire.getDatabase();
        dataFire.getElectionDataRef().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    aboutBundle.putString(ARG_ABOUT,snapshot.child(ARG_ABOUT).getValue().toString());
                    aboutBundle.putString(ARG_ACHIEVEMENT,snapshot.child(ARG_ACHIEVEMENT).getValue().toString());
                    aboutBundle.putString(ARG_ELECTION,snapshot.child(ARG_ELECTION).getValue().toString());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}