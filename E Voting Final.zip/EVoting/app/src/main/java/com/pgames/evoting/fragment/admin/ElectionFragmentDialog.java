package com.pgames.evoting.fragment.admin;

import android.os.Bundle;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.Query;
import com.pgames.evoting.R;
import com.pgames.evoting.adapter.AdminElectionViewAdapter;
import com.pgames.evoting.models.AdminElectionView;
import com.pgames.evoting.models.DataFire;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ElectionFragmentDialog#newInstance} factory method to
 * create an instance of this fragment.
 *
 */
public class ElectionFragmentDialog extends DialogFragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";

    // TODO: Rename and change types of parameters
    private String mParamTitle;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private AdminElectionViewAdapter adapter;
    private DataFire dataFire;
    // TODO: Rename and change types and number of parameters
    public static ElectionFragmentDialog newInstance(String title) {
        ElectionFragmentDialog fragment = new ElectionFragmentDialog();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, title);
        fragment.setArguments(args);
        return fragment;
    }

    public ElectionFragmentDialog() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParamTitle = getArguments().getString(ARG_PARAM1);
        }

        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_election_dialog, container, false);
        widget(view);

        Query query = dataFire.getElectionListRef().child(mParamTitle);
        FirebaseRecyclerOptions<AdminElectionView> options = new FirebaseRecyclerOptions.Builder<AdminElectionView>()
                .setQuery(query,AdminElectionView.class)
                .build();
        adapter = new AdminElectionViewAdapter(options,getContext());
        recyclerView.setAdapter(adapter);

        return view;
    }

    private void widget(View view) {
    recyclerView = (RecyclerView) view.findViewById(R.id.rclr_election_candidate);
    layoutManager = new LinearLayoutManager(getContext());
    recyclerView.setLayoutManager(layoutManager);
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}