package com.pgames.evoting.fragment.voter;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.core.graphics.BitmapCompat;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.common.Blocked;
import com.pgames.evoting.fragment.common.Login;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.User;

import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

public class VoterProfile extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_NAME = "name";
    private static final String ARG_EMAIL = "email";
    private static final String ARG_CONTACT = "contact";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";
    private static final String ARG_IS_ADMIN = "isAdmin";
    private static final String ARG_IS_APPROVE_VOTER = "isApproveVoter";
    private static final String ARG_IS_CANDIDATE = "isCandidate";
    private static final String ARG_IS_APPROVE_CANDIDATE = "isApproveCandidate";
    private static final String ARG_IS_REQUEST_VOTER = "isRequestVoter";
    private static final String ARG_IS_REQUEST_CANDIDATE = "isRequestCandidate";
    private static final String ARG_DEPT_INDEX = "deptIndex";
    private static final String ARG_YEAR_INDEX = "yearIndex";
    private static final String ARG_BTN_APPLY_CAND_STATE = "btnApplyCandState";
    private static final String ARG_BTN_SAVE_STATE = "btnSaveState";
    private static final String ARG_PROFILE_PIC = "profile";

    private String mParamName;
    private String mParamEmail;
    private String mParamProfile;
    private boolean mParamVoterReq;
    private boolean mParamCandReq;
    private boolean mParamApprCandidate, mParamApprVoter, mParamCand;
    private String mParamBtnSaveSate;
    private String mParamBtnApplySate;
    private String mParamContact;
    private String mParamYear;
    private String mParamDept;
    private TextInputEditText mName, mContactNumber, mEmail;
    private Spinner mDepartment, mYear;
    private Button mSave, mAppyForCandidate, mSignOut;
    private ImageView mImgClose, mImgSave;
    private TextView mYearTv;
    private TextView mApproveInfo;
    private DataFire dataFire;
    private ImageView mProfilePhoto;
    private Uri mProfilePhotoUri = null;

    public VoterProfile() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            //string parameters
            mParamName = getArguments().getString(ARG_NAME);
            mParamEmail = getArguments().getString(ARG_EMAIL);
            mParamContact = getArguments().getString(ARG_CONTACT);
            mParamYear = getArguments().getString(ARG_YEAR);
            mParamDept = getArguments().getString(ARG_DEPT);
            mParamBtnSaveSate = getArguments().getString(ARG_BTN_SAVE_STATE);
            mParamBtnApplySate = getArguments().getString(ARG_BTN_APPLY_CAND_STATE);
            mParamProfile = getArguments().getString(ARG_PROFILE_PIC);
            //Boolean parameters
            mParamVoterReq = getArguments().getBoolean(ARG_IS_REQUEST_VOTER);
            mParamCandReq = getArguments().getBoolean(ARG_IS_REQUEST_CANDIDATE);
            mParamApprCandidate = getArguments().getBoolean(ARG_IS_APPROVE_CANDIDATE);
            mParamApprVoter = getArguments().getBoolean(ARG_IS_APPROVE_VOTER);
            mParamCand = getArguments().getBoolean(ARG_IS_CANDIDATE);
        }

        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                System.exit(0);
            }
        };

        requireActivity().getOnBackPressedDispatcher().addCallback(onBackPressedCallback);

        //Firebase instances
        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
        dataFire.getStorageRef();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_voter_profile, container, false);
        //initialization
        widget(view);
        listener();
        setDataUI();

        if (dataFire.getUser() != null)
            dataFire.getUserRef().child("status").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        try {
                            if (snapshot.getValue().toString().equals("blocked")) {
                                Log.e("User", snapshot.getValue().toString());
                                Objects.requireNonNull(getActivity()).getSupportFragmentManager()
                                        .beginTransaction()
                                        .replace(R.id.main_host_fragment, new Blocked())
                                        .commit();
                            }
                        } catch (NullPointerException pointerException) {
//                            Log.e("Blocked Exp",pointerException.getMessage());
                            pointerException.printStackTrace();
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.e("Deveice Id", "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        String token = task.getResult().getToken();
                        dataFire.getApplyingRef().child(token).setValue("registered");
                        Log.e("Device Id", token);
                        if (getContext() != null)
                            dataFire.getApplyingRef().addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        try {
                                            for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                                if (!dataSnapshot.getKey().equals(token))
                                                    Log.e("Snapshot", dataSnapshot.getValue().toString());

                                                if (!dataSnapshot.getKey().equals(token))
                                                    if (dataSnapshot.getValue().toString().equals("applying")) {
                                                        if (getContext() != null) {
                                                            mAppyForCandidate.setText("Already applying someone");
                                                            mAppyForCandidate.setEnabled(false);
                                                        }
                                                    } else {
                                                        dataFire.getUserRef().child("data").child("isRequestCandidate").addListenerForSingleValueEvent(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                                if (snapshot.exists()){
                                                                    try {
                                                                        mParamCandReq = (boolean) snapshot.getValue();
                                                                    }catch (NullPointerException e){
                                                                        e.printStackTrace();
                                                                    }

                                                                }
                                                                setDataUI();
                                                            }

                                                            @Override
                                                            public void onCancelled(@NonNull DatabaseError error) {

                                                            }
                                                        });
                                                    }
                                            }
                                        } catch (Exception e) {
                                            Log.e("Nominee", e.getMessage());
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });

                    }
                });

        dataFire.getUserRef().child("data").child("isCandidate").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    boolean checkCandidate = (boolean) snapshot.getValue();
                    if (checkCandidate) {
                        if (getActivity() != null)
                            startActivity(Intent.makeRestartActivityTask(getActivity().getIntent().getComponent()));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return view;
    }

    private static void deleteCache(Context context) {
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if (dir != null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }

    private void listener() {
        //sign out
        mSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dataFire.getmAuth().signOut();
                deleteCache(getContext());
                ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new Login());
            }
        });

        //Save Data
        mSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, Object> userMap = new HashMap<>();
                if (mSave.getText().equals(getString(R.string.save))) {
                    if (validation()) {
                        mSave.setEnabled(false);
                        disableUI(true);
                        mApproveInfo.setVisibility(View.VISIBLE);
                        mApproveInfo.setText(getText(R.string.uploading_image));
                        final ProgressDialog progressdialog = new ProgressDialog(getActivity());
                        progressdialog.setTitle("Uploading.....");
                        progressdialog.show();
                        UploadTask uploadTask = dataFire.getPhotoRef().putBytes(getByteFromBitmap(mProfileBitmap));
                        uploadTask.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                                double progress
                                        = (100.0 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();

                                progressdialog.setMessage(((int) progress) + "% uploading....");
                            }
                        });

                        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                            @Override
                            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                                if (!task.isSuccessful()) {
                                    throw Objects.requireNonNull(task.getException());
                                }

                                // Continue with the task to get the download URL
                                return dataFire.getPhotoRef().getDownloadUrl();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                            }
                        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    Uri downloadUri = task.getResult();
//                                    Toast.makeText(getContext(), downloadUri.toString(), Toast.LENGTH_SHORT).show();
                                    Log.e("downloadUrl-->", "" + downloadUri.toString());
                                    progressdialog.dismiss();
                                    Log.e("Profile", "upload success");
                                    mApproveInfo.setVisibility(View.GONE);
                                    mApproveInfo.setText(getString(R.string.waiting_approval));
                                    mSave.setText(getText(R.string.send_approval));
                                    mSave.setEnabled(true);
                                    userMap.put("data", new User(mName.getText().toString(),
                                            mEmail.getText().toString(),
                                            false,
                                            mDepartment.getSelectedItem().toString(),
                                            mYear.getSelectedItem().toString(),
                                            mContactNumber.getText().toString(),
                                            false,
                                            false,
                                            false,
                                            true,
                                            false,
                                            mDepartment.getSelectedItemPosition(),
                                            mYear.getSelectedItemPosition(),
                                            getString(R.string.send_approval),
                                            "none",
                                            downloadUri.toString()));
                                    mParamProfile = downloadUri.toString();
                                    dataFire.getUserRef().updateChildren(userMap)
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        disableUI(true);
                                                    }
                                                }
                                            });
                                } else {
                                    // Handle failures
                                    // ...
                                }
                            }
                        });
                    }


                } else if (mSave.getText().equals(getString(R.string.send_approval))) {
                    Log.e("URL", dataFire.getPhotoRef().getDownloadUrl().toString());
                    mSave.setEnabled(false);
                    Map<String, String> reqMap = new HashMap<>();
                    reqMap.put(ARG_NAME, mParamName);
                    reqMap.put(ARG_DEPT, mDepartment.getSelectedItem().toString());
                    reqMap.put(ARG_YEAR, mYear.getSelectedItem().toString());
                    reqMap.put("uid", dataFire.getUserID());
                    reqMap.put("photo", mParamProfile);
                    //require profile photo
                    dataFire.getVoterReqRef().child(dataFire.getUserRef().push().getKey()).setValue(reqMap)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    dataFire.getUserRef().child("data")
                                            .child(ARG_BTN_SAVE_STATE)
                                            .setValue(getString(R.string.request_sent))
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    mSave.setText(getText(R.string.request_sent));
                                                    mSignOut.setVisibility(View.VISIBLE);
                                                    mApproveInfo.setVisibility(View.VISIBLE);
                                                    if (!mParamApprVoter)
                                                        dataFire.getUserRef().child("data").child("isApproveVoter").addValueEventListener(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                                if (snapshot.exists()) {
                                                                    boolean checkVoter = (boolean) snapshot.getValue();
                                                                    if (getActivity() != null)
                                                                        if (checkVoter) {
                                                                            startActivity(Intent.makeRestartActivityTask(getActivity().getIntent().getComponent()));
                                                                        }
                                                                }
                                                            }

                                                            @Override
                                                            public void onCancelled(@NonNull DatabaseError error) {

                                                            }
                                                        });
                                                }
                                            });

                                }
                            });
                } else if (mSave.getText().equals(getString(R.string.edit_profile))) {
                    Log.e("Profile", "edit");
                    mSave.setText(getString(R.string.make_change));
                    disableUI(false);

                } else if (mSave.getText().equals(getString(R.string.make_change))) {
                    if (validation()) {
                        mSave.setEnabled(false);
                        disableUI(true);
                    }


                }
            }
        });
//
//        //Save Data using top image
//        mImgSave.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                //save data
//            }
//        });
//
//        //close profile
//        mImgClose.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                ((MainActivity) Objects.requireNonNull(getActivity())).onBackPressed();
//            }
//        });


        //apply for candidate
        mAppyForCandidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //apply for nomination
                Log.e("Profile", "nomination");
                ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new NomineeRegistration());
            }
        });

        mProfilePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!editAction) {
                    loadDataSpinner(getContext());
                }
                selectImage();
            }
        });
    }

    private void widget(View view) {
        Toolbar toolbar = view.findViewById(R.id.tool_profile);
        TextView textView = view.findViewById(R.id.txt_toolbar_title);
        textView.setText(R.string.profile);
        //TextView
        mYearTv = (TextView) view.findViewById(R.id.txt_voter_year);
        mApproveInfo = view.findViewById(R.id.txt_approve_info);
        mApproveInfo.setVisibility(View.GONE);

        //EditText
        mEmail = (TextInputEditText) view.findViewById(R.id.edt_voter_email_final);
        mEmail.setEnabled(false);
        mContactNumber = (TextInputEditText) view.findViewById(R.id.edt_voter_contact_number_final);
        mName = (TextInputEditText) view.findViewById(R.id.edt_voter_name_final);

        //Spinner
        mDepartment = (Spinner) view.findViewById(R.id.spnr_voter_dept);
        mYear = (Spinner) view.findViewById(R.id.spnr_voter_year);

        //Button
        mSave = (Button) view.findViewById(R.id.btn_voter_save);
        mAppyForCandidate = (Button) view.findViewById(R.id.btn_apply_candidate);
        mSignOut = (Button) view.findViewById(R.id.voter_sign_out);
        //ImageView
        mImgClose = (ImageView) view.findViewById(R.id.img_btn_toolbar_close);
        mImgSave = (ImageView) view.findViewById(R.id.img_btn_toolbar_save);
        mProfilePhoto = (ImageView) view.findViewById(R.id.resultImage);
    }


    private void selectImage() {
        final CharSequence[] options = {"Take Photo", "Choose From Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(R.string.choose_profile_photo);
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @SuppressLint("QueryPermissionsNeeded")
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo")) {
                    Intent takePicture = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 0);

                } else if (options[item].equals("Choose From Gallery")) {
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhoto, 1);

                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private Bitmap mProfileBitmap;
    private boolean photoValidate = false;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 0:
                    if (resultCode == RESULT_OK && data != null) {
                        Bitmap selectedImage = (Bitmap) data.getExtras().get("data");
                        mProfileBitmap = selectedImage;
                        photoValidate = true;
                        mProfilePhoto.setImageBitmap(selectedImage);
                    }

                    break;
                case 1:
                    if (resultCode == RESULT_OK && data != null) {
                        Uri selectedImage = data.getData();
//                        mProfilePhotoUri = selectedImage;
                        InputStream inputStream = null;
                        try {
                            inputStream = Objects.requireNonNull(getActivity()).getBaseContext().getContentResolver().openInputStream(selectedImage);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        Bitmap bm = BitmapFactory.decodeStream(inputStream);
                        mProfileBitmap = bm;
                        photoValidate = true;
                        mProfilePhoto.setImageBitmap(bm);
                    }
                    break;

            }
        }
    }

    private static byte[] getByteFromBitmap(Bitmap bmp) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 20, stream);
        Log.e("Size", String.valueOf(bmp.getByteCount()));
        return stream.toByteArray();
    }

    public String getPath(Uri uri) {
        // just some safety built in
        if (uri == null) {
            return null;
        }
        // try to retrieve the image from the media store first
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContext().getContentResolver().query(uri,
                projection, null, null, null);
        if (cursor != null) {
            int column_index = cursor
                    .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            String path = cursor.getString(column_index);
            cursor.close();
            return path;
        }
        // this is our fallback here
        return uri.getPath();
    }

    boolean editAction = false;

    @SuppressLint("UseCompatLoadingForDrawables")
    private void setDataUI() {
        //Set values
        try {
            Log.e("Save", mSave.getText().toString());
            mName.setText(mParamName);
            mEmail.setText(mParamEmail);
            if (mParamBtnSaveSate.equals(getString(R.string.send_approval)) || mParamBtnSaveSate.equals(getString(R.string.request_sent))) {
                Log.e("Approval", "inside");
                if (dataFire.getPhotoRef() != null)
                    Glide.with(getContext()).load(dataFire.getPhotoRef()).into(mProfilePhoto);
            }
            if (!mParamVoterReq) {
                loadDataSpinner(getContext());
            }

            if (mParamVoterReq) {
                if (mParamDept.equals("none") && mParamYear.equals("none")) {
                    loadDataSpinner(getContext());
                } else {
                    final List<String> department = new ArrayList<>();
                    final List<String> year = new ArrayList<>();
                    department.add(mParamDept);
                    year.add(mParamYear);
                    ArrayAdapter<String> deptAdapter = new ArrayAdapter<>(getContext(), R.layout.custome_spinner, department);
                    ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(getContext(), R.layout.custome_spinner, year);
                    mDepartment.setAdapter(deptAdapter);
                    mYear.setAdapter(yearAdapter);
                }
                mContactNumber.setText(mParamContact);
                mYearTv.setVisibility(View.VISIBLE);
                mYear.setVisibility(View.VISIBLE);
                //Set save button states

                if (mParamBtnSaveSate.equals(getString(R.string.save))) {
                    mSave.setText(mParamBtnSaveSate);
                } else if (mParamBtnSaveSate.equals(getString(R.string.send_approval))) {
                    mSave.setText(mParamBtnSaveSate);
                    disableUI(true);
                } else if (mParamBtnSaveSate.equals(getString(R.string.request_sent))) {
                    mSave.setText(getText(R.string.request_sent));
                    mSave.setEnabled(false);
                    mSignOut.setVisibility(View.VISIBLE);
                    mApproveInfo.setVisibility(View.VISIBLE);
                    disableUI(true);
                    if (!mParamApprVoter)
                        dataFire.getUserRef().child("data").child("isApproveVoter").addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    boolean checkVoter = (boolean) snapshot.getValue();
                                    if (getActivity() != null)
                                        if (checkVoter) {
                                            startActivity(Intent.makeRestartActivityTask(getActivity().getIntent().getComponent()));
                                        }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                }

            } else {
                loadDataSpinner(getContext());
            }

            if (mParamApprVoter) {
                mApproveInfo.setVisibility(View.GONE);
//                mSave.setText(getString(R.string.edit_profile));
                mSave.setVisibility(View.INVISIBLE);
                editAction = true;
                mSave.setEnabled(true);
                SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
                String get_key = mParamEmail + getString(R.string.candidate_applied);
//                boolean applied = sharedPref.getBoolean(get_key,false);
//                if (applied){
//                    mAppyForCandidate.setVisibility(View.VISIBLE);
//                    mAppyForCandidate.setText(getString(R.string.waiting_approval));
//                    mAppyForCandidate.setEnabled(false);
//                }else mAppyForCandidate.setVisibility(View.VISIBLE);

                Log.e("VoterReq", String.valueOf(mParamCand));
                if (mParamApprVoter && !mParamCandReq) {
                    mAppyForCandidate.setText(getString(R.string.candidate_apply));
                    mAppyForCandidate.setEnabled(true);
                    mAppyForCandidate.setVisibility(View.VISIBLE);
                } else if (mParamApprVoter && mParamCandReq) {
                    mAppyForCandidate.setVisibility(View.VISIBLE);
                    mAppyForCandidate.setText(getString(R.string.waiting_approval));
                    mAppyForCandidate.setEnabled(false);
                }
            }


        } catch (Exception e) {
            Log.e("ProfileExp", e.getMessage());
        }
    }

    private void loadDataSpinner(Context context) {
        //load data into Departments
        dataFire.getAcademicRef().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    final List<String> department = new ArrayList<>();
                    final List<String> year = new ArrayList<>();
                    if (snapshot.exists()) {
                        department.add("");
                        year.add("");
                        for (DataSnapshot deptSanp : snapshot.child("departments").getChildren()) {
                            String deptName = Objects.requireNonNull(deptSanp.getValue()).toString();
                            department.add(deptName);
                        }
                        for (DataSnapshot yearSnap : snapshot.child("years").getChildren()) {
                            String yearName = Objects.requireNonNull(yearSnap.getValue()).toString();
                            year.add(yearName);
                        }
                        //sort departments
                        Collections.sort(department);
                        department.set(0, "Select Department");
                        //sort year
                        Collections.sort(year);
                        year.set(0, "Select Year");

                        //set adapter to department
                        ArrayAdapter<String> deptAdapter = new ArrayAdapter<String>(context, R.layout.custome_spinner, department);
                        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(context, R.layout.custome_spinner, year);
                        //set dropdown view resources to view spniner list in desire style
                        deptAdapter.setDropDownViewResource(R.layout.custome_spinner);
                        yearAdapter.setDropDownViewResource(R.layout.custome_spinner);
                        //add adapter to department
                        mDepartment.setAdapter(deptAdapter);
                        //add adapter to year
                        mYear.setAdapter(yearAdapter);

                        //listner
                        mDepartment.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                if (position > 0) {
                                    mYearTv.setVisibility(View.VISIBLE);
                                    mYear.setSelection(0);
                                    mYear.setVisibility(View.VISIBLE);
                                } else {
                                    mYearTv.setVisibility(View.GONE);
                                    mYear.setVisibility(View.GONE);
                                }
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {

                            }
                        });
                    }
                } catch (Exception e) {
                    Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private boolean validation() {
        String number = mContactNumber.getText().toString();
        String name = mName.getText().toString();
        if (!photoValidate) {
            if (editAction) {
                return true;
            } else Toast.makeText(getContext(), "Upload Profile Photo", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (name.isEmpty()) {
            mName.setError("enter name");
            return false;
        }

        if (number.length() != 10) {
            mContactNumber.setError("enter valid contact");
            return false;
        }

        if (mDepartment.getSelectedItem().equals("Select Department")) {
            Toast.makeText(getContext(), "Select Department and Year", Toast.LENGTH_SHORT).show();
            return false;
        }


        return !mYear.getSelectedItem().equals("Select Year");
    }

    private void disableUI(boolean check) {
        if (check) {
            mProfilePhoto.setEnabled(false);
            mName.setEnabled(false);
            mContactNumber.setEnabled(false);
            mDepartment.setEnabled(false);
            mYear.setEnabled(false);
        } else {
            mProfilePhoto.setEnabled(false);
            mName.setEnabled(true);
            mContactNumber.setEnabled(true);
            mDepartment.setEnabled(false);
            mYear.setEnabled(false);
        }
    }

}