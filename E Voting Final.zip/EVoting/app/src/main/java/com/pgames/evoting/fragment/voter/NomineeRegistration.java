package com.pgames.evoting.fragment.voter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.models.DataFire;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NomineeRegistration#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NomineeRegistration extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String ARG_NAME = "name";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";
    private static final String ARG_PROFILE_PIC = "profile";
    private static final String ARG_EMAIL = "email";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private TextInputEditText mAbout, mAchievments;
    private Button mApply;
    private ImageView mImgClose, mImgSave;
    private Spinner mElectionList;
    private DataFire dataFire;
    private String mParamName;
    private String mParamYear;
    private String mParamDept;
    private String mParamProfile;
    private String mParamEmail;
    private RequestQueue mRequestQueue;
    private Date todaysDate;

    public NomineeRegistration() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment NomineeRegistration.
     */
    // TODO: Rename and change types and number of parameters
    public static NomineeRegistration newInstance(String param1, String param2) {
        NomineeRegistration fragment = new NomineeRegistration();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            mParamName = getArguments().getString(ARG_NAME);
            mParamYear = getArguments().getString(ARG_YEAR);
            mParamDept = getArguments().getString(ARG_DEPT);
            mParamProfile = getArguments().getString(ARG_PROFILE_PIC);
            mParamEmail = getArguments().getString(ARG_EMAIL);
        }

        getdata();

        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (getActivity() != null)
                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new VoterProfile());
            }
        };

        requireActivity().getOnBackPressedDispatcher().addCallback(onBackPressedCallback);

        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_nominee_registration, container, false);
        //initialize
        widget(view);
        //listner
        listner();
        loadElections(getContext());
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.e("Deveice Id", "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        String token = task.getResult().getToken();
                        dataFire.getApplyingRef().child(token).setValue("applying");
                        Log.e("Device Id", token);

                        if (getContext()!=null)
                        dataFire.getApplyingRef().addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    try {
                                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                            if (!dataSnapshot.getKey().equals(token))
                                                Log.e("Snapshot", dataSnapshot.getValue().toString());

                                            if (!dataSnapshot.getKey().equals(token))
                                                if (dataSnapshot.getValue().toString().equals("applying")) {
                                                    if (getContext()!=null) {
                                                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                                                        builder.setTitle("Nomination Notice")
                                                                .setMessage("Already applying someone with same login\nPlease Go Back!")
                                                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                                                    @Override
                                                                    public void onClick(DialogInterface dialog, int which) {
                                                                        dialog.dismiss();
                                                                        if (getContext() != null)
                                                                            ((MainActivity) getActivity()).startFragment(new VoterProfile());
                                                                    }
                                                                })
                                                                .setCancelable(false)
                                                                .create()
                                                                .show();
                                                    }
                                                }
                                        }
                                    }catch (Exception e){
                                        Log.e("Nominee",e.getMessage());
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                });


        return view;
    }

    private void listner() {
        //Request for nomination
        mApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    Map<String, String> nominationMap = new HashMap<>();
                    String electionType = mElectionList.getSelectedItem().toString();
                    String about = mAbout.getText().toString();
                    String achievements = mAchievments.getText().toString();
                    nominationMap.put("election", electionType);
                    nominationMap.put("about", about);
                    nominationMap.put("achievements", achievements);
                    nominationMap.put("uid", dataFire.getUserID());
                    nominationMap.put("photo", mParamProfile);
                    nominationMap.put("name", mParamName);
                    nominationMap.put("department", mParamDept);
                    nominationMap.put("year", mParamYear);

                    dataFire.getNomineeReqRef().child(dataFire.getNomineeReqRef().push().getKey()).setValue(nominationMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                dataFire.getUserRef().child("data").child("isRequestCandidate").setValue(true);
                                dataFire.getElectionDataRef().child("about").setValue(about);
                                dataFire.getElectionDataRef().child("achievements").setValue(achievements);
                                dataFire.getElectionDataRef().child("election").setValue(electionType)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
//                                                    SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
//                                                    SharedPreferences.Editor editor = sharedPref.edit();
//                                                    String key_name = mParamEmail + getString(R.string.candidate_applied);
//                                                    editor.putBoolean(key_name, true);
//                                                    editor.apply();
//                                                    ((MainActivity) Objects.requireNonNull(getActivity())).restartFragment(new VoterProfile());
//                                                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new VoterProfile());
                                                    startActivity(Intent.makeRestartActivityTask(Objects.requireNonNull(getActivity()).getIntent().getComponent()));
                                                }
                                            }
                                        });
                            }
                        }
                    });
                }
            }
        });

        //Top right save button
        mImgSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation())
                    Toast.makeText(getContext(), "Applyied", Toast.LENGTH_SHORT).show();
            }
        });


        //close
        mImgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) Objects.requireNonNull(getActivity())).onBackPressed();
            }
        });
    }

    private boolean validation() {
        if (mElectionList.getSelectedItem().equals(getString(R.string.select_election))) {
            Toast.makeText(getContext(), "Please Select election you want to be nominated", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!mAbout.getText().toString().isEmpty()) {
            Log.e("About", "not empty");
            mAbout.setError(null);
        } else {
            mAbout.setError(getString(R.string.error_nomination));
            return false;
        }
        if (!mAchievments.getText().toString().isEmpty()) {
            Log.e("Achieve", "not empty");
            mAbout.setError(null);
        } else {
            mAchievments.setError(getString(R.string.error_nomination));
            return false;
        }
        return true;
    }

    public void getdata() {
        Response.Listener<String> response_listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Log.e("Response", response);
                    // JSONArray jsonArray = new JSONArray(response);
                    String object = new JSONObject(response).getString("datetime");
                    Log.e("Todays date", object);
                    //JSONObject jsonObject = jsonArray.getJSONObject(0);
                    //Log.e("date", String.valueOf(jsonObject.getString("abbreviation")));
//                    Toast.makeText(mContext, object, Toast.LENGTH_SHORT).show();
                    String formatDate = object.substring(0, Math.min(object.length(), 10));
                    String year = formatDate.substring(0, Math.min(formatDate.length(), 4));
                    String month = formatDate.substring(5, Math.min(formatDate.length(), 7));
                    String day = formatDate.substring(8, Math.min(formatDate.length(), 10));
                    String finalDate = day + "/" + month + "/" + year;

                    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                    todaysDate = df.parse(finalDate);
                } catch (JSONException | ParseException e) {
                    e.printStackTrace();
                }
            }
        };


        Response.ErrorListener response_error_listener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                    Log.e("TimeError", error.getMessage());
                } else if (error instanceof AuthFailureError) {
                    //TODO
                    Log.e("AuthFail", error.getMessage());
                } else if (error instanceof ServerError) {
                    //TODO
                    Log.e("Server", error.getMessage());
                } else if (error instanceof NetworkError) {
                    //TODO
                    Log.e("NetworkFail", error.getMessage());
                } else if (error instanceof ParseError) {
                    //TODO
                    Log.e("ParseFail", error.getMessage());
                }
            }
        };

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://worldtimeapi.org/api/timezone/Asia/Kolkata", response_listener, response_error_listener);
        getRequestQueue().add(stringRequest);
    }

    public RequestQueue getRequestQueue() {
        //requestQueue is used to stack your request and handles your cache.
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        }
        return mRequestQueue;
    }

    String checkDialogStatus = "close";

    private void loadElections(Context context) {
        if (dataFire.getUser() != null) {
            if (getContext() != null)
                dataFire.getScheduleRef().addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        final List<String> electionList = new ArrayList<>();
                        if (snapshot.exists()) {
                            try {
                                if (checkDialogStatus.equals("open")) {
//                                startActivity(Intent.makeRestartActivityTask(getActivity().getIntent().getComponent()));
                                    ((MainActivity) getActivity()).restartFragment(new NomineeRegistration());
                                }

                                electionList.add("");
                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                                    try {
                                        Date eleStartdate = format.parse(dataSnapshot.child("startDateElection").getValue().toString());
                                        Date nomStartdate = format.parse(dataSnapshot.child("startDateNomination").getValue().toString());
                                        Date eleEnddate = format.parse(dataSnapshot.child("endDateElection").getValue().toString());
                                        Date nomEnddate = format.parse(dataSnapshot.child("endDateNomination").getValue().toString());
                                        if (todaysDate.compareTo(nomEnddate) <= 0 && todaysDate.compareTo(nomStartdate) >= 0) {
                                            String electionTitle = Objects.requireNonNull(dataSnapshot.child("title").getValue()).toString();
                                            electionList.add(electionTitle);
                                        }else if (format.format(todaysDate).equals(format.format(nomStartdate)) || format.format(todaysDate).equals(format.format(nomEnddate))){
                                            String electionTitle = Objects.requireNonNull(dataSnapshot.child("title").getValue()).toString();
                                            electionList.add(electionTitle);
                                        }
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }
                                }
                                //sort Elections
                                Collections.sort(electionList);
                                electionList.set(0, getString(R.string.select_election));
                                //set adapter to Election list
                                ArrayAdapter<String> electionListAdapter = new ArrayAdapter<String>(context, R.layout.custome_spinner, electionList);
                                //set dropdown view resources to view spniner list in desire style
                                electionListAdapter.setDropDownViewResource(R.layout.custome_spinner);
                                //add adapter to department
                                mElectionList.setAdapter(electionListAdapter);
                                if ((electionList.size() < 2)) {
                                    mElectionList.setEnabled(false);
                                    mAbout.setEnabled(false);
                                    mAchievments.setEnabled(false);
                                    mApply.setEnabled(false);
                                    Toast.makeText(context, "Nomination not started yet!", Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                Log.e("NomineeExp", e.getMessage());
                            }

                        } else {
                            mElectionList.setEnabled(false);
                            mAbout.setEnabled(false);
                            mAchievments.setEnabled(false);
                            mApply.setEnabled(false);
//                        Toast.makeText(context, "Elections not scheduled!", Toast.LENGTH_SHORT).show();
                            if (getContext() != null) {
                                checkDialogStatus = "open";
                                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                                builder.setTitle("Nomination Notice")
                                        .setMessage("Elections not scheduled by admin\nPlease contact admin to apply nomination for elections")
                                        .setPositiveButton("Go Back!", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                                checkDialogStatus = "close";
                                                if (getContext() != null)
                                                    ((MainActivity) getActivity()).startFragment(new VoterProfile());
                                            }
                                        }).create().show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
        }
    }

    private void widget(View view) {
        Toolbar toolbar = view.findViewById(R.id.tool_profile);
        TextView textView = view.findViewById(R.id.txt_toolbar_title);
        textView.setText(R.string.nominition_title);

        //TextInputEditText
        mAbout = (TextInputEditText) view.findViewById(R.id.edt_about_final);
        mAchievments = (TextInputEditText) view.findViewById(R.id.edt_achivements_final);

        //Button
        mApply = (Button) view.findViewById(R.id.btn_apply);

        //Image Views
        mImgClose = (ImageView) view.findViewById(R.id.img_btn_toolbar_close);
        mImgSave = (ImageView) view.findViewById(R.id.img_btn_toolbar_save);

        //spinner
        mElectionList = (Spinner) view.findViewById(R.id.spnr_election_loader);
        todaysDate = new Date();
    }
}