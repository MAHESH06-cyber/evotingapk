package com.pgames.evoting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.fragment.admin.AdminHome;
import com.pgames.evoting.fragment.candidate.CandidateProfile;
import com.pgames.evoting.fragment.common.Blocked;
import com.pgames.evoting.fragment.common.Results;
import com.pgames.evoting.fragment.common.Splash;
import com.pgames.evoting.fragment.voter.CandidateDetails;
import com.pgames.evoting.fragment.voter.UpcommingElections;
import com.pgames.evoting.fragment.voter.VoterProfile;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.utils.BottomNavigationBehavior;

import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;
    private CoordinatorLayout.LayoutParams layoutParams;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initialize
        widget();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }

        }

        //call splash screen
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.main_host_fragment, new Splash())
                .commit();
//        updateUI(dataFire.getUser());
        checkUserStatus();
        bottomNavigationView.setVisibility(View.GONE);
    }

    private int mDashId = R.layout.fragment_results;
    private int mHomeId = R.layout.fragment_upcomming_elections;
    private int mProfileId = R.layout.fragment_voter_profile;

    private final BottomNavigationView.OnNavigationItemSelectedListener navLister =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @SuppressLint("NonConstantResourceId")
                @Override
                public boolean onNavigationItemSelected(MenuItem menuItem) {
                    Fragment selectedFragment = null;
                    switch (menuItem.getItemId()) {
                        case R.id.bottom_nav_home:
                            selectedFragment = mHomeId == R.layout.fragment_upcomming_elections ? new UpcommingElections() :
                                    mHomeId == R.layout.fragment_candidate_details ? new CandidateDetails() : new UpcommingElections();
                            break;
                        case R.id.bottom_nav_dashboard:
                            selectedFragment = mDashId == R.layout.fragment_results ? new Results() :
                                    new Results();
                            break;
                        case R.id.bottom_nav_profile:
                            if (paramIsCandidate && paramIsVoter)
                                selectedFragment = new CandidateProfile();
                            else if (paramIsVoter || !paramIsCandidate) {
                                selectedFragment = new VoterProfile();
                            }
                            break;
                    }

                    assert selectedFragment != null;
                    startFragment(selectedFragment);


                    return true;
                }
            };


    private void widget() {
//        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_host_fragment);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
        bundle = new Bundle();

    }

    public void hideBottomNavBar() {
        bottomNavigationView.setVisibility(View.GONE);
    }

    public void showBottomNavBar() {
//        updateUI(dataFire.getUser());
        checkUserStatus();
        bottomNavigationView.setVisibility(View.VISIBLE);
        bottomNavigationView.setOnNavigationItemSelectedListener(navLister);
        // attaching bottom sheet behaviour - hide / show on scroll
        layoutParams = (CoordinatorLayout.LayoutParams) bottomNavigationView.getLayoutParams();
        layoutParams.setBehavior(new BottomNavigationBehavior());

    }

    public void startFragment(Fragment fragment) {
        fragment.setArguments(bundle);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.main_host_fragment, fragment)
                .commit();
    }

    public void restartFragment(Fragment fragment) {
        fragment.setArguments(bundle);
        getSupportFragmentManager()
                .beginTransaction()
                .detach(fragment)
                .attach(fragment)
                .commit();
    }

    public boolean validateUI(String type, String email, String password) {
        switch (type) {
            case "email":
                String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." +
                        "[a-zA-Z0-9_+&*-]+)*@" +
                        "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                        "A-Z]{2,7}$";

                Pattern pat = Pattern.compile(emailRegex);
                if (email.equals(""))
                    return false;
                return pat.matcher(email).matches();
            case "password":
                if (!((password.length() >= 8)
                        && (password.length() <= 15))) {
                    return false;
                }

                // to check space
                if (password.contains(" ")) {
                    return false;
                }
                if (true) {
                    int count = 0;

                    // check digits from 0 to 9
                    for (int i = 0; i <= 9; i++) {

                        // to convert int to string
                        String str1 = Integer.toString(i);

                        if (password.contains(str1)) {
                            count = 1;
                        }
                    }
                    if (count == 0) {
                        return false;
                    }
                }

                // for special characters
                if (!(password.contains("@") || password.contains("#")
                        || password.contains("!") || password.contains("~")
                        || password.contains("$") || password.contains("%")
                        || password.contains("^") || password.contains("&")
                        || password.contains("*") || password.contains("(")
                        || password.contains(")") || password.contains("-")
                        || password.contains("+") || password.contains("/")
                        || password.contains(":") || password.contains(".")
                        || password.contains(", ") || password.contains("<")
                        || password.contains(">") || password.contains("?")
                        || password.contains("|"))) {
                    return false;
                }

                //Capital letter check
//                if (true) {
//                    int count = 0;
//
//                    // checking capital letters
//                    for (int i = 65; i <= 90; i++) {
//
//                        // type casting
//                        char c = (char)i;
//
//                        String str1 = Character.toString(c);
//                        if (password.contains(str1)) {
//                            count = 1;
//                        }
//                    }
//                    if (count == 0) {
//                        return false;
//                    }
//                }

                if (true) {
                    int count = 0;

                    // checking small letters
                    for (int i = 90; i <= 122; i++) {

                        // type casting
                        char c = (char) i;
                        String str1 = Character.toString(c);

                        if (password.contains(str1)) {
                            count = 1;
                        }
                    }
                    if (count == 0) {
                        return false;
                    }
                }

                // if all conditions fails
                return true;
        }

        return false;
    }


    private static final String ARG_NAME = "name";
    private static final String ARG_EMAIL = "email";
    private static final String ARG_CONTACT = "contact";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";
    private static final String ARG_IS_ADMIN = "isAdmin";
    private static final String ARG_IS_APPROVE_VOTER = "isApproveVoter";
    private static final String ARG_IS_CANDIDATE = "isCandidate";
    private static final String ARG_IS_APPROVE_CANDIDATE = "isApproveCandidate";
    private static final String ARG_IS_REQUEST_VOTER = "isRequestVoter";
    private static final String ARG_IS_REQUEST_CANDIDATE = "isRequestCandidate";
    private static final String ARG_DEPT_INDEX = "deptIndex";
    private static final String ARG_YEAR_INDEX = "yearIndex";
    private static final String ARG_BTN_APPLY_CAND_STATE = "btnApplyCandState";
    private static final String ARG_BTN_SAVE_STATE = "btnSaveState";
    private static final String ARG_PROFILE_PIC = "profile";
    private DataFire dataFire;


    private boolean paramIsCandidate;
    private boolean paramIsVoter;
    private Bundle bundle;

    public static int loggedIn = 0;

    private void checkUserStatus() {
        if (dataFire.getUser() != null)
            dataFire.getUserRef().child("status").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        if (snapshot.getValue().toString().equals("blocked")) {
                            ++loggedIn;
                            Log.e("User", snapshot.getValue().toString());
                            getSupportFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.main_host_fragment, new Blocked())
                                    .commit();
                        } else if (snapshot.getValue().toString().equals("active")) {
                            updateUI(dataFire.getUser());
                        }
                    } else {
                        updateUI(dataFire.getUser());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        else updateUI(dataFire.getUser());

    }

    private void updateUI(FirebaseUser user) {
        if (user != null)
            dataFire.getUserRef()
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists())
                                try {
                                    Map<String, Map<String, Object>> userDataMap = (Map) snapshot.getValue();
                                    assert userDataMap != null;
                                    bundle.putString(ARG_NAME, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_NAME));
                                    bundle.putString(ARG_EMAIL, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_EMAIL));
                                    bundle.putString(ARG_CONTACT, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_CONTACT));
                                    bundle.putBoolean(ARG_IS_ADMIN, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_ADMIN));
                                    bundle.putBoolean(ARG_IS_APPROVE_CANDIDATE, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_CANDIDATE));
                                    bundle.putBoolean(ARG_IS_APPROVE_VOTER, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_VOTER));
                                    bundle.putBoolean(ARG_IS_REQUEST_CANDIDATE, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_REQUEST_CANDIDATE));
                                    bundle.putBoolean(ARG_IS_REQUEST_VOTER, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_REQUEST_VOTER));
                                    bundle.putBoolean(ARG_IS_CANDIDATE, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_CANDIDATE));
                                    if (snapshot.child("data").child(ARG_PROFILE_PIC).exists()) {
                                        bundle.putString(ARG_PROFILE_PIC, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_PROFILE_PIC));
                                    } else bundle.putString(ARG_PROFILE_PIC, "");
                                    if (snapshot.child("data").child(ARG_DEPT).exists())
                                        bundle.putString(ARG_DEPT, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_DEPT));
                                    else bundle.putString(ARG_DEPT, "none");
                                    if (snapshot.child("data").child(ARG_YEAR).exists())
                                        bundle.putString(ARG_YEAR, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_YEAR));
                                    else bundle.putString(ARG_YEAR, "none");

                                    if (snapshot.child("data").child(ARG_BTN_SAVE_STATE).exists())
                                        bundle.putString(ARG_BTN_SAVE_STATE, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_BTN_SAVE_STATE));
                                    else
                                        bundle.putString(ARG_BTN_SAVE_STATE, (String) getText(R.string.save));

                                    if (snapshot.child("data").child(ARG_BTN_APPLY_CAND_STATE).exists())
                                        bundle.putString(ARG_BTN_APPLY_CAND_STATE, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_BTN_SAVE_STATE));
                                    else
                                        bundle.putString(ARG_BTN_APPLY_CAND_STATE, (String) getText(R.string.candidate_apply));
//                                    if ((boolean) userDataMap.get("data").get(ARG_IS_APPROVE_CANDIDATE)){
//                                        mProfileId = R.layout.fragment_candidate_profile;
//                                    }else {
//                                        mProfileId = R.layout.fragment_voter_profile;
//                                    }

                                    paramIsCandidate = (boolean) userDataMap.get("data").get(ARG_IS_CANDIDATE);
                                    paramIsVoter = (boolean) userDataMap.get("data").get(ARG_IS_APPROVE_VOTER);

                                    Log.e("Check", paramIsCandidate + " " + paramIsVoter);
                                } catch (Exception e) {
//                                    Log.e("SplashExp", e.getMessage());
                                }
                            else startFragment(new AdminHome());

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Log.e("Login Database error", error.getMessage());
                        }
                    });
    }

}