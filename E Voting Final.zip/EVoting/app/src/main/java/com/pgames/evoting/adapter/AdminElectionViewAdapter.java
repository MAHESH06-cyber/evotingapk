package com.pgames.evoting.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.ServerValue;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.voter.CandidateInfo;
import com.pgames.evoting.models.AdminElectionView;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.VotingList;

public class AdminElectionViewAdapter extends FirebaseRecyclerAdapter<AdminElectionView, AdminElectionViewAdapter.ViewHolder> {


    private static final String ARG_NAME = "name";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";
    private static final String ARG_PROFILE_PIC = "profile";
    private static final String ARG_ABOUT = "about";
    private static final String ARG_ACHIEVEMENT = "achievements";
    private Context mContext;
    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public AdminElectionViewAdapter(@NonNull FirebaseRecyclerOptions<AdminElectionView> options,Context context) {
        super(options);
        mContext = context;
    }


    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull AdminElectionView model) {
        holder.name.setText(model.getName());
        holder.department.setText(model.getDepartment());
        holder.year.setText(model.getYear());

        Glide.with(mContext).load(model.getPhoto()).into(holder.photo);
        holder.photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isSelected) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                    builder.setTitle("Candidate Profile")
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                    CandidateInfo candidateInfo = CandidateInfo.newInstance(builder);
                    Bundle bundle = new Bundle();
                    bundle.putString(ARG_NAME, model.getName());
                    bundle.putString(ARG_YEAR, model.getYear());
                    bundle.putString(ARG_DEPT, model.getDepartment());
                    bundle.putString(ARG_PROFILE_PIC, model.getPhoto());
                    bundle.putString(ARG_ABOUT, model.getAbout());
                    bundle.putString(ARG_ACHIEVEMENT, model.getAchievements());
                    candidateInfo.setArguments(bundle);
                    candidateInfo.setShowsDialog(true);
                    candidateInfo.show(((MainActivity) mContext).getSupportFragmentManager(), "Candidate Info");
                }
            }
        });
    }
    private boolean isSelected = false;
    private void voted(VotingListAdapter.ViewHolder holder, VotingList model){
        holder.mCardView.setCardBackgroundColor(Color.GRAY);
        holder.voted.setVisibility(View.VISIBLE);
        DataFire dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
        dataFire.getVotingRef().child(model.getElection()).child(model.getUid()).child(dataFire.getUserID()).setValue(ServerValue.TIMESTAMP);
        dataFire.getUserVotedRef().child(model.getElection()).setValue(ServerValue.TIMESTAMP);

        isSelected = true;
    }
    private void welcomeMsg(){
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setMessage(R.string.voter_msg)
                .setCancelable(false)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .create()
                .show();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custome_voting, parent, false);
        return new ViewHolder(view);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView name;
        public TextView department;
        public TextView year;
        public ImageView photo;
        public CardView mCardView;
        public ImageView voted;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.req_name);
            this.department = (TextView) view.findViewById(R.id.req_dept);
            this.year = (TextView) view.findViewById(R.id.req_year);
            this.photo = (ImageView) view.findViewById(R.id.req_photo);
            this.mCardView = (CardView) view.findViewById(R.id.voting_card);
            this.voted = (ImageView) view.findViewById(R.id.voted);
        }
    }
}
