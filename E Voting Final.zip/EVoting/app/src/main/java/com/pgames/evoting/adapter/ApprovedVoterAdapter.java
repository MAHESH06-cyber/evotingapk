package com.pgames.evoting.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.pgames.evoting.R;
import com.pgames.evoting.models.ApprovedVoter;
import com.pgames.evoting.models.DataFire;

import org.w3c.dom.Text;

public class ApprovedVoterAdapter extends FirebaseRecyclerAdapter<ApprovedVoter, ApprovedVoterAdapter.ViewHolder> {

    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */

    private Context mContext;
    private DataFire dataFire;

    public ApprovedVoterAdapter(@NonNull FirebaseRecyclerOptions<ApprovedVoter> options, Context context) {
        super(options);
        mContext = context;
        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull ApprovedVoter model) {
        holder.name.setText(model.getName());
        holder.department.setText(model.getDepartment());
        holder.year.setText(model.getYear());
        Glide.with(mContext).load(model.getPhoto()).into(holder.photo);

        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
        try {
            if (model.getStatus().equals("blocked")){
                Log.e(model.getName(),model.getStatus());
                holder.reject.setBackground(mContext.getDrawable(R.drawable.btn_accept_square));
            }else if (model.getStatus().equals("active")){
                Log.e(model.getName(),model.getStatus());
                holder.reject.setBackground(mContext.getDrawable(R.drawable.btn_block));
            }
        }catch (NullPointerException pointerException){
            Log.e("Exp",pointerException.getMessage());
        }

        holder.reject.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("UseCompatLoadingForDrawables")
            @Override
            public void onClick(View v) {
                try {

                    if (model.getStatus().equals("active")){
                        dataFire.getApprovedVoterRef().child(itemRef.getKey()).child("status").setValue("blocked");
                        dataFire.getDatabase().getReference().child("users").child(model.getUid()).child("status").setValue("blocked").addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful())
                                    holder.reject.setBackground(mContext.getDrawable(R.drawable.btn_accept_square));
                            }
                        });
                    }else {
                        dataFire.getApprovedVoterRef().child(itemRef.getKey()).child("status").setValue("active");
                        dataFire.getDatabase().getReference().child("users").child(model.getUid()).child("status").setValue("active").addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful())
                                    holder.reject.setBackground(mContext.getDrawable(R.drawable.btn_block));
                            }
                        });
                    }
                }catch (NullPointerException pointerException){
                    Log.e("Pointer",pointerException.getMessage());
                    dataFire.getApprovedVoterRef().child(itemRef.getKey()).child("status").setValue("blocked");
                    dataFire.getDatabase().getReference().child("users").child(model.getUid()).child("status").setValue("blocked").addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful())
                                holder.reject.setBackground(mContext.getDrawable(R.drawable.btn_accept_square));
                        }
                    });
                }
            }
        });

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custome_approved_list, parent, false);
        return new ViewHolder(view);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public TextView department;
        public TextView year;
        public ImageView photo;
        public TextView reject;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.req_name);
            this.department = (TextView) view.findViewById(R.id.req_dept);
            this.year = (TextView) view.findViewById(R.id.req_year);
            this.photo = (ImageView) view.findViewById(R.id.req_photo);
            this.reject = (TextView) view.findViewById(R.id.req_reject);
        }
    }
}
