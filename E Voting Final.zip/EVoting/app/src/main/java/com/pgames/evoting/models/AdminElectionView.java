package com.pgames.evoting.models;

public class AdminElectionView {
    private String name;
    private String uid;
    private String year;
    private String department;
    private String photo;
    private String about;
    private String achievements;
    private String election;

    public AdminElectionView(String name, String uid, String year, String department, String photo, String about, String achievements, String election) {
        this.name = name;
        this.uid = uid;
        this.year = year;
        this.department = department;
        this.photo = photo;
        this.about = about;
        this.achievements = achievements;
        this.election = election;
    }

    public AdminElectionView() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getAchievements() {
        return achievements;
    }

    public void setAchievements(String achievements) {
        this.achievements = achievements;
    }

    public String getElection() {
        return election;
    }

    public void setElection(String election) {
        this.election = election;
    }
}
