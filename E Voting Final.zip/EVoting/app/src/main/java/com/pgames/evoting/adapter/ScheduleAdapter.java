package com.pgames.evoting.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.admin.AdminScheduleElection;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.Schedule;

import java.util.Objects;

public class ScheduleAdapter extends FirebaseRecyclerAdapter<Schedule, ScheduleAdapter.ViewHolder> {

    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */

    private Context mContext;
    public ScheduleAdapter(@NonNull FirebaseRecyclerOptions<Schedule> options, Context context) {
        super(options);
        mContext = context;
    }

    private final static String ARG_TITLE = "title";
    private final static String ARG_START_DATE_ELECTION = "startDateElection";
    private final static String ARG_END_DATE_ELECTION = "endDateElection";
    private final static String ARG_START_DATE_NOMINATION = "startDateNomination";
    private final static String ARG_END_DATE_NOMINATION = "endDateNomination";
    private final static String ARG_ACTION_EDIT_KEY = "edit";
    private final static String ARG_UPDATE_ACTION = "update";

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Schedule model) {
        holder.title.setText(model.getTitle());
        String eleDate = model.getStartDateElection() +" to " + model.getEndDateElection();
        holder.electionDate.setText(eleDate);


        //Edit schedule
        holder.scheduleEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle  = new Bundle();
                bundle.putString(ARG_TITLE,model.getTitle());
                bundle.putString(ARG_START_DATE_ELECTION,model.getStartDateElection());
                bundle.putString(ARG_END_DATE_ELECTION,model.getEndDateElection());
                bundle.putString(ARG_START_DATE_NOMINATION,model.getStartDateNomination());
                bundle.putString(ARG_END_DATE_NOMINATION,model.getEndDateNomination());
                DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                bundle.putString(ARG_ACTION_EDIT_KEY, itemRef.getKey());
                bundle.putString(ARG_UPDATE_ACTION,"update");
                AdminScheduleElection adminScheduleElection = new AdminScheduleElection();
                adminScheduleElection.setArguments(bundle);
                ((MainActivity)mContext)
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.main_host_fragment,adminScheduleElection)
                        .commit();
//                FragmentManager fragmentManager = ((FragmentActivity)mContext).getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.main_host_fragment, fragment);
//                fragmentTransaction.commit();

            }
        });

        //Delete schedule
        holder.scheduleDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DataFire dataFire = new DataFire();
                dataFire.getmAuth();
                dataFire.getDatabase();
                dataFire.getElectionListRef().child(model.getTitle()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()){
                            dataFire.getElectionListRef().child(model.getTitle()).removeValue();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

                DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                dataFire.getScheduleRef().child(itemRef.getKey()).removeValue();
            }
        });
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custome_schedule, parent, false);
        return new ViewHolder(view);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
    public TextView title;
    public TextView electionDate;
    public TextView scheduleEdit,scheduleDelete;
    public ViewHolder(@NonNull View view) {
        super(view);
        this.title = (TextView) view.findViewById(R.id.txt_title);
        this.electionDate = (TextView) view.findViewById(R.id.txt_date);
        this.scheduleEdit = (TextView) view.findViewById(R.id.btn_schedule_edit);
        this.scheduleDelete = (TextView) view.findViewById(R.id.btn_schedule_delete);
    }
}
}
