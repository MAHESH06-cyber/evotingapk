package com.pgames.evoting.fragment.voter;

import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.models.DataFire;

import org.w3c.dom.Text;

import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CandidateDetails#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CandidateDetails extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String ARG_NAME = "name";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";
    private static final String ARG_PROFILE_PIC = "profile";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private ImageView mProfilePhoto, mBack;
    private TextView mName, mYear, mDept, mAbout, mAchievements;
    private String mParamProfile;
    private String mParamDept;
    private String mParamYear;
    private String mParamName;
    private DataFire dataFire;

    public CandidateDetails() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CandidateDetails.
     */
    // TODO: Rename and change types and number of parameters
    public static CandidateDetails newInstance(String param1, String param2) {
        CandidateDetails fragment = new CandidateDetails();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            mParamName = getArguments().getString(ARG_NAME);
            mParamYear = getArguments().getString(ARG_YEAR);
            mParamDept = getArguments().getString(ARG_DEPT);
            mParamProfile = getArguments().getString(ARG_PROFILE_PIC);
        }

        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new UpcommingElections());
            }
        };

        requireActivity().getOnBackPressedDispatcher().addCallback(onBackPressedCallback);

        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_candidate_details, container, false);
        widget(view);
        ((MainActivity) Objects.requireNonNull(getActivity())).hideBottomNavBar();
        listner();
        setData();
        return view;
    }

    private void setData() {
        if (dataFire.getUser() != null) {
            mName.setText(mParamName);
            mDept.setText(mParamDept);
            mYear.setText(mParamYear);
            Glide.with(getContext()).load(mParamProfile).into(mProfilePhoto);
            dataFire.getElectionDataRef().addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        if (snapshot.child("about").exists())
                            mAbout.setText(snapshot.child("about").getValue().toString());
                        if (snapshot.child("achievements").exists())
                            mAchievements.setText(snapshot.child("achievements").getValue().toString());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }

    private void listner() {
        //get Back
        mBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) Objects.requireNonNull(getActivity())).onBackPressed();
            }
        });
    }

    private void widget(View view) {
        //TextView
        mAbout = (TextView) view.findViewById(R.id.txt_candidate_about);
        mAchievements = (TextView) view.findViewById(R.id.txt_candidate_achivements_details);
        mName = (TextView) view.findViewById(R.id.txt_candidate_name);
        mDept = (TextView) view.findViewById(R.id.txt_candidate_dept);
        mYear = (TextView) view.findViewById(R.id.txt_candidate_year);

        //ImageView
        mBack = (ImageView) view.findViewById(R.id.img_btn_back_candidate);
        mProfilePhoto = (ImageView) view.findViewById(R.id.resultImage);

    }
}