package com.pgames.evoting.fragment.admin;

import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toolbar;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.adapter.VoterRequestsAdapter;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.VoterRequests;

import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AdminVotersRequest#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AdminVotersRequest extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private DataFire dataFire;
    private VoterRequestsAdapter adapter;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private TextView mVoterInfo;
    private RadioButton mPending, mRejected;
    private RadioGroup mRadioGroup;

    public AdminVotersRequest() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AdminVotersRequest.
     */
    // TODO: Rename and change types and number of parameters
    public static AdminVotersRequest newInstance(String param1, String param2) {
        AdminVotersRequest fragment = new AdminVotersRequest();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        //Function while system back pressed called
        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (getActivity() != null)
                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new AdminHome());
            }
        };
        //calling onBackPressed callback
        requireActivity()
                .getOnBackPressedDispatcher()
                .addCallback(this, onBackPressedCallback);


        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_voters_request, container, false);
        //initialization
        widget(view);
        loadRequests();
        listener();
        return view;
    }

    private void loadRequests() {
        FirebaseRecyclerOptions<VoterRequests> options = new FirebaseRecyclerOptions.Builder<VoterRequests>()
                .setQuery(dataFire.getVoterReqRef(), VoterRequests.class)
                .build();
        adapter = new VoterRequestsAdapter(options,getContext());
        recyclerView.setAdapter(adapter);
        dataFire.getVoterReqRef().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    if (snapshot.exists()) {
                        mVoterInfo.setVisibility(View.GONE);
                    }
                    else {
                        mVoterInfo.setText(getString(R.string.no_data_found));
                        mVoterInfo.setVisibility(View.VISIBLE);
                    }
                }catch (IllegalStateException illegalStateException){
                    Log.e("VoterRequest",illegalStateException.getMessage());
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void widget(View view) {
        //Setup toolbar
        Toolbar toolbar = view.findViewById(R.id.tool_nominies);
        TextView textView = view.findViewById(R.id.txt_toolbar_title);
        textView.setText(R.string.voter);
        ImageView back = view.findViewById(R.id.img_btn_toolbar_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)Objects.requireNonNull(getActivity())).onBackPressed();
            }
        });

        recyclerView = view.findViewById(R.id.recycler_voters);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        //textview
        mVoterInfo = (TextView) view.findViewById(R.id.voter_info);

        //radio button
        mPending = (RadioButton) view.findViewById(R.id.rdb_pending_voter);
        mRejected = (RadioButton) view.findViewById(R.id.rdb_rejected_voter);

        //radio group
        mRadioGroup = (RadioGroup) view.findViewById(R.id.rdbg_entity_selection);
    }

    public static boolean rejected = false;
    private void listener() {
        //pending
        mPending.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    rejected = false;
                    Log.e("Pending", String.valueOf(isChecked));
                    FirebaseRecyclerOptions<VoterRequests> options = new FirebaseRecyclerOptions.Builder<VoterRequests>()
                            .setQuery(dataFire.getVoterReqRef(), VoterRequests.class)
                            .build();
                    adapter.updateOptions(options);
                    dataFire.getVoterReqRef().addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            try {
                                if (snapshot.exists()) {
                                    mVoterInfo.setVisibility(View.GONE);
                                }
                                else {
                                    mVoterInfo.setText(getString(R.string.no_data_found));
                                    mVoterInfo.setVisibility(View.VISIBLE);
                                }
                            }catch (IllegalStateException illegalStateException){
                                Log.e("VoterRequest",illegalStateException.getMessage());
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }
            }
        });

        //rejected
        mRejected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    rejected = true;
                    Log.e("Rejected", String.valueOf(isChecked));
                    FirebaseRecyclerOptions<VoterRequests> options = new FirebaseRecyclerOptions.Builder<VoterRequests>()
                            .setQuery(dataFire.getVoterRejectedRef(), VoterRequests.class)
                            .build();
                    adapter.updateOptions(options);
                    dataFire.getVoterRejectedRef().addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            try {
                                if (snapshot.exists()) {
                                    mVoterInfo.setVisibility(View.GONE);
                                }
                                else {
                                    mVoterInfo.setText(getString(R.string.no_data_found_rejected));
                                    mVoterInfo.setVisibility(View.VISIBLE);
                                }
                            }catch (IllegalStateException illegalStateException){
                                Log.e("VoterRequest",illegalStateException.getMessage());
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}