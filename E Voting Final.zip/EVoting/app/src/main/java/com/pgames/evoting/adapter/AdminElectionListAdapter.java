package com.pgames.evoting.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.admin.ElectionFragmentDialog;
import com.pgames.evoting.models.AdminElectionList;
import com.pgames.evoting.models.DataFire;

public class AdminElectionListAdapter extends FirebaseRecyclerAdapter<AdminElectionList, AdminElectionListAdapter.ViewHolder> {


    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    private DataFire dataFire;
    private Context mContext;

    public AdminElectionListAdapter(@NonNull FirebaseRecyclerOptions<AdminElectionList> options, Context context) {
        super(options);
        mContext = context;
        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }


    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull AdminElectionList model) {
        dataFire.getElectionListRef().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        String electionTitle = dataSnapshot.getKey();
                        assert electionTitle != null;
                        if (electionTitle.equals(model.getTitle())) {
                            holder.title.setText(model.getTitle());
                            String date = model.getStartDateElection() + " to " + model.getEndDateElection();
                            holder.electionDate.setText(date);
                        }else {
                            holder.eleCard.setVisibility(View.GONE);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        holder.eleCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ElectionFragmentDialog fragmentDialog = ElectionFragmentDialog.newInstance(model.getTitle());
                fragmentDialog.setShowsDialog(true);
                fragmentDialog.show(((MainActivity)mContext).getSupportFragmentManager(),"ElectionDialog");
            }
        });


    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custome_schedule_upcoming, parent, false);
        return new ViewHolder(view);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public TextView electionDate;
        public Button scheduleVote;
        public CardView eleCard;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.txt_title);
            this.electionDate = (TextView) view.findViewById(R.id.txt_date);
            this.scheduleVote = (Button) view.findViewById(R.id.btn_schedule_vote);
            this.scheduleVote.setVisibility(View.GONE);
            this.eleCard = (CardView) view.findViewById(R.id.election_card);
        }
    }
}
