package com.pgames.evoting.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.voter.ScheduleShow;
import com.pgames.evoting.fragment.voter.Voting;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.ElectionList;
import com.pgames.evoting.models.Schedule;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Timer;

public class ElectionListAdapter extends FirebaseRecyclerAdapter<ElectionList, ElectionListAdapter.ViewHolder> {


    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */

    private Context mContext;
    private static final String ARG_TITLE = "title";
    private RequestQueue mRequestQueue;
    private static Date todaysDate ;
    String object = "";
    public ElectionListAdapter(@NonNull FirebaseRecyclerOptions<ElectionList> options, Context context) {
        super(options);
        mContext = context;
        todaysDate = new Date();
        getdata();
    }

    public void getdata(){
        Response.Listener<String> response_listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Log.e("Response",response);
                   // JSONArray jsonArray = new JSONArray(response);
                    object = new JSONObject(response).getString("datetime");


                    //JSONObject jsonObject = jsonArray.getJSONObject(0);
                    //Log.e("date", String.valueOf(jsonObject.getString("abbreviation")));
//                    Toast.makeText(mContext, object, Toast.LENGTH_SHORT).show();

                    String formatDate = object.substring(0,Math.min(object.length(),10));
                    String year = formatDate.substring(0,Math.min(formatDate.length(),4));
                    String month = formatDate.substring(5,Math.min(formatDate.length(),7));
                    String day = formatDate.substring(8,Math.min(formatDate.length(),10));
                    String finalDate = day+"/"+month+"/"+year;

                    Log.e("Final Date",finalDate);
                    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault());
                     todaysDate = df.parse(finalDate);

                    Log.e("Todays date",String.valueOf(todaysDate));
                } catch (JSONException | ParseException e) {
                    e.printStackTrace();
                    Log.e("Exp",e.getMessage());
                }
            }
        };


        Response.ErrorListener response_error_listener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                try {
                    if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                        Log.e("TimeError",error.getMessage());
                    } else if (error instanceof AuthFailureError) {
                        //TODO
                        Log.e("AuthFail",error.getMessage());
                    } else if (error instanceof ServerError) {
                        //TODO
                        Log.e("Server",error.getMessage());
                    } else if (error instanceof NetworkError) {
                        //TODO
                        Log.e("NetworkFail",error.getMessage());
                    } else if (error instanceof ParseError) {
                        //TODO
                        Log.e("ParseFail",error.getMessage());
                    }
                }catch (Exception e){
                    Log.e("Response",e.getMessage());
                }

            }
        };

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://worldtimeapi.org/api/timezone/Asia/Kolkata",response_listener,response_error_listener);
        getRequestQueue().add(stringRequest);
    }

    public RequestQueue getRequestQueue() {
        //requestQueue is used to stack your request and handles your cache.
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(mContext);
        }
        return mRequestQueue;
    }
    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull ElectionList model) {
        holder.title.setText(model.getTitle());
        String date = model.getStartDateElection() + " to " + model.getEndDateElection();
        holder.electionDate.setText(date);
//        Date currentDate = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
//        String formattedDate = df.format(currentDate);
        try {
            Date expDate = df.parse(model.getEndDateElection());
            Date startDate = df.parse(model.getStartDateElection());


            if (todaysDate.compareTo(expDate) > 0) {
                assert expDate != null;
                if (df.format(todaysDate).equals(df.format(expDate))){
                    holder.scheduleVote.setText(mContext.getString(R.string.vote));
                    holder.scheduleVote.setEnabled(true);
                }else {
                    holder.scheduleVote.setText(mContext.getString(R.string.expired));
                    holder.scheduleVote.setEnabled(false);
                }

            } else if (todaysDate.compareTo(startDate) < 0) {
                holder.scheduleVote.setText(mContext.getString(R.string.comming_soom));
                holder.scheduleVote.setEnabled(false);
            } else if (todaysDate.compareTo(expDate) <= 0 && todaysDate.compareTo(startDate) >= 0) {
                holder.scheduleVote.setText(mContext.getString(R.string.vote));
                holder.scheduleVote.setEnabled(true);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        holder.eleCard.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("UseCompatLoadingForDrawables")
            @Override
            public void onClick(View v) {
                androidx.appcompat.app.AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setTitle("Schedule for "+model.getTitle())
                        .setIcon(mContext.getDrawable(R.drawable.calender))
                        .setCancelable(false)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                ScheduleShow scheduleShow = ScheduleShow.newInstance(builder);
                Bundle bundle = new Bundle();
                bundle.putString("es",mContext.getString(R.string.election_start)+":"+model.getStartDateElection());
                bundle.putString("ee",mContext.getString(R.string.election_end)+":"+model.getEndDateElection());
                bundle.putString("ns",mContext.getString(R.string.nomination_start)+":"+model.getStartDateNomination());
                bundle.putString("ne",mContext.getString(R.string.nomination_end)+":"+model.getEndDateNomination());
                scheduleShow.setArguments(bundle);
                scheduleShow.setShowsDialog(true);
                scheduleShow.show(((MainActivity) mContext).getSupportFragmentManager(), "Candidate Info");
            }
        });

        holder.scheduleVote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString(ARG_TITLE, model.getTitle());
                Voting voting = new Voting();
                voting.setArguments(bundle);
                ((MainActivity) mContext).getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.main_host_fragment, voting)
                        .commit();
            }
        });

        DataFire dataFire = new DataFire();
        dataFire.getDatabase();
        dataFire.getUserVotedRef().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    //prepare voting booth
                    if (!snapshot.child(model.getTitle()).exists()) {
                        holder.scheduleVote.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Bundle bundle = new Bundle();
                                bundle.putString(ARG_TITLE, model.getTitle());
                                Voting voting = new Voting();
                                voting.setArguments(bundle);
                                ((MainActivity) mContext).getSupportFragmentManager()
                                        .beginTransaction()
                                        .replace(R.id.main_host_fragment, voting)
                                        .commit();
                            }
                        });
                    } else {
                        holder.scheduleVote.setText(mContext.getString(R.string.voted));
                        holder.scheduleVote.setEnabled(false);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custome_schedule_upcoming, parent, false);
        return new ViewHolder(view);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public TextView electionDate;
        public Button scheduleVote;
        public CardView eleCard;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.txt_title);
            this.electionDate = (TextView) view.findViewById(R.id.txt_date);
            this.scheduleVote = (Button) view.findViewById(R.id.btn_schedule_vote);
            this.eleCard = (CardView) view.findViewById(R.id.election_card);
        }
    }
}
