package com.pgames.evoting.fragment.admin;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.voter.UpcommingElections;
import com.pgames.evoting.models.DataFire;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GetResult#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GetResult extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private Spinner mElectionSelector;
    private DataFire dataFire;
    private LinearLayout linearLayoutCandName;
    private LinearLayout mCandidateDetails;
    private PieChart mResultPieChart;
    private TextView mWinner;
    private TextView mDetailsText;
    private CardView mBottomPanel;
    private ScrollView mScrollVoter;
    public GetResult() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment GetResult.
     */
    // TODO: Rename and change types and number of parameters
    public static GetResult newInstance(String param1, String param2) {
        GetResult fragment = new GetResult();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                ((MainActivity)getActivity()).startFragment(new AdminHome());
            }
        };
        getActivity().getOnBackPressedDispatcher().addCallback(onBackPressedCallback);


        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_get_result, container, false);
        widget(view);

        dataFire.getDatabase().getReference().child("result").child("release").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    if (snapshot.getValue().toString().equals("yes")){
                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                        builder.setTitle("Stop showing results")
                                .setCancelable(false)
                                .setPositiveButton("Stop Result Showing", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dataFire.getDatabase().getReference().child("result").child("release").setValue("no").addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                dialog.dismiss();
                                                ((MainActivity)getActivity()).startFragment(new AdminHome());

                                            }
                                        });

                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        updateUI(dataFire.getUser(), getContext());
                                        listner();
//                                        dataFire.getDatabase().getReference().child("result").child("release").setValue("yes").addOnCompleteListener(new OnCompleteListener<Void>() {
//                                            @Override
//                                            public void onComplete(@NonNull Task<Void> task) {
//                                                if (task.isSuccessful())
//                                                    dialog.dismiss();
//                                            }
//                                        });

                                        dialog.dismiss();
                                    }
                                })
                                .setMessage("Results are released")
                                .create().show();
                    }else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                        builder.setTitle("Show results")
                                .setCancelable(false)
                                .setNegativeButton("Go Back!", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dataFire.getDatabase().getReference().child("result").child("release").setValue("no").addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                dialog.dismiss();
                                                ((MainActivity)getActivity()).startFragment(new AdminHome());

                                            }
                                        });

                                    }
                                })
                                .setPositiveButton("Show results", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        updateUI(dataFire.getUser(), getContext());
                                        listner();
                                        dataFire.getDatabase().getReference().child("result").child("release").setValue("yes").addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful())
                                                    dialog.dismiss();
                                            }
                                        });
                                    }
                                })
                                .setMessage("Are you sure?\nShow result again to the students")
                                .create().show();
                    }
                }else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle(getActivity().getString(R.string.release_result))
                            .setCancelable(false)
                            .setNegativeButton("Not now", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dataFire.getDatabase().getReference().child("result").child("release").setValue("no").addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            dialog.dismiss();
                                            ((MainActivity)getActivity()).startFragment(new AdminHome());

                                        }
                                    });

                                }
                            })
                            .setPositiveButton("Release", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    updateUI(dataFire.getUser(), getContext());
                                    listner();
                                    dataFire.getDatabase().getReference().child("result").child("release").setValue("yes").addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful())
                                                dialog.dismiss();
                                        }
                                    });
                                }
                            })
                            .setMessage("Are you sure?\nIf you release result it available to all students for view!")
                            .create().show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        return view;
    }

    final List<String> candidateList = new ArrayList<>();
    final Map<String, Integer> votingMap = new HashMap<>();
    final static Map<String, Map<String, String>> candMap = new HashMap<>();
    final static Map<String, String> detailsMap = new HashMap<>();
    final List<Integer> scoreList = new ArrayList<>();
    private void listner() {
        if(getContext()!=null)
            mElectionSelector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (!parent.getItemAtPosition(position).equals(getString(R.string.select_election))) {
                        mBottomPanel.setVisibility(View.VISIBLE);
                        mScrollVoter.setVisibility(View.VISIBLE);
                        if (((LinearLayout) linearLayoutCandName).getChildCount() > 0) {
                            ((LinearLayout) linearLayoutCandName).removeAllViews();
                            mResultPieChart.clearChart();
                            int count = mCandidateDetails.getChildCount()-1;
                            for (int i=count; i> 0 ;i--){
                                mCandidateDetails.removeViewAt(i);
                            }

                            mWinner.setText(null);
                        }
                        String selectedItem = parent.getItemAtPosition(position).toString();
                        for (int i = 0; i < candidateList.size(); i++) {
                            String s = candidateList.get(i);
                            if (dataMap.get(selectedItem).get(s) != null) {
                                dataFire.getDatabase().getReference().child("users").child(s).child("data").addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if (snapshot.exists()) {
                                            Random rnd = new Random();
                                            int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                                            TextView textView = new TextView(getContext());
                                            textView.setText(snapshot.child("name").getValue().toString());
                                            //for textview
                                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                                    LinearLayout.LayoutParams.WRAP_CONTENT
                                            );
                                            params.gravity = Gravity.CENTER;
                                            textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                                            params.setMargins(getSizeDP(8), 0, 0, 0);
                                            textView.setLayoutParams(params);
                                            textView.setTextColor(color);

                                            //Creating new Layout
                                            LinearLayout layout = new  LinearLayout(getContext());
                                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                            layoutParams.gravity = Gravity.CENTER_VERTICAL;
                                            layout.setLayoutParams(layoutParams);
                                            layout.setOrientation(LinearLayout.HORIZONTAL);

                                            //Creating legend box
                                            ImageView imageView = new ImageView(getContext());
                                            imageView.setBackgroundColor(color);
                                            imageView.setLayoutParams(new ViewGroup.LayoutParams(getSizeDP(16),getSizeDP(16)));

                                            //set legend
                                            layout.addView(imageView);
                                            layout.addView(textView);

                                            //add legend lo main view
                                            linearLayoutCandName.addView(layout);

                                            //set candidates data
                                            TextView name = new TextView(getContext());
                                            TextView department = new TextView(getContext());
                                            TextView year = new TextView(getContext());
                                            TextView votes = new TextView(getContext());
                                            RelativeLayout relativeLayout = new RelativeLayout(getContext());
                                            RelativeLayout.LayoutParams relativeParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                                            relativeParams.setMarginStart(getSizeDP(16));
                                            relativeLayout.setLayoutParams(relativeParams);
                                            RelativeLayout.LayoutParams relativeParamsEnd = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                                            relativeLayout.setLayoutParams(relativeParams);

                                            LinearLayout.LayoutParams candTxtParam = new LinearLayout.LayoutParams(
                                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                                    LinearLayout.LayoutParams.WRAP_CONTENT
                                            );
                                            candTxtParam.setMargins(getSizeDP(16),0,0,0);
                                            department.setLayoutParams(candTxtParam);
                                            year.setLayoutParams(candTxtParam);
                                            relativeParams.alignWithParent = true;
                                            name.setLayoutParams(relativeParams);

                                            relativeParamsEnd.addRule(RelativeLayout.ALIGN_PARENT_END);
                                            relativeParamsEnd.setMarginEnd(getSizeDP(24));
                                            votes.setLayoutParams(relativeParamsEnd);

                                            //set Text
                                            name.setText(snapshot.child("name").getValue().toString());
                                            department.setText(snapshot.child("department").getValue().toString());
                                            year.setText(snapshot.child("year").getValue().toString());
                                            votes.setText(String.valueOf(votingMap.get(s)));

                                            //set Color
                                            name.setTextColor(color);
                                            department.setTextColor(color);
                                            year.setTextColor(color);
                                            votes.setTextColor(color);

                                            relativeLayout.addView(name);
                                            relativeLayout.addView(votes);
                                            LinearLayout candDetails = new LinearLayout(getContext());
                                            LinearLayout.LayoutParams candDetailsParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                            candDetailsParams.setMargins(getSizeDP(16),0,0,getSizeDP(8));
                                            candDetails.setLayoutParams(candDetailsParams);
                                            candDetails.setOrientation(LinearLayout.HORIZONTAL);
                                            candDetails.addView(department);
                                            candDetails.addView(year);
                                            mCandidateDetails.addView(relativeLayout);
                                            mCandidateDetails.addView(candDetails);


                                            mWinner.setVisibility(View.VISIBLE);
                                            mDetailsText.setVisibility(View.VISIBLE);

                                            //set winner
                                            int maxValue = 0;
                                            String winnerId = "";
                                            String winnerName = "";
                                            String winnerDept = "";
                                            String winnerYear = "";
                                            int winnerVotes = 0;
                                            if(votingMap.get(s)> maxValue){
                                                maxValue = votingMap.get(s);
                                                winnerId = s;
                                                winnerName = snapshot.child("name").getValue().toString();
                                                winnerDept = snapshot.child("department").getValue().toString();
                                                winnerYear = snapshot.child("year").getValue().toString();
                                                winnerVotes = votingMap.get(s);
                                            }
                                            String winText = getString(R.string.election_winner) + " "+winnerName+"\n"+winnerDept+"\n"+winnerYear+"\nHas votes "+winnerVotes;
                                            mWinner.setText(winText);
                                            Log.e("Winner is "+winnerName+" "+maxValue,winnerId);

                                            //set chart
                                            mResultPieChart.addPieSlice(new PieModel(
                                                    textView.getText().toString(),
                                                    votingMap.get(s),
                                                    color
                                            ));
                                        }
                                        mResultPieChart.startAnimation();

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                        Log.e("Error", error.getMessage());
                                    }
                                });

                            }
                        }
                    } else {
                        if (((LinearLayout) linearLayoutCandName).getChildCount() > 0)
                            ((LinearLayout) linearLayoutCandName).removeAllViews();
                        mResultPieChart.clearChart();
                        TextView textView = new TextView(getContext());
                        textView.setText(getString(R.string.result_waiting));
                        linearLayoutCandName.addView(textView);
                        int count = mCandidateDetails.getChildCount()-1;
                        for (int i=count; i> 0 ;i--){
                            mCandidateDetails.removeViewAt(i);
                        }
                        mWinner.setVisibility(View.INVISIBLE);
                        mDetailsText.setVisibility(View.INVISIBLE);
                        mBottomPanel.setVisibility(View.INVISIBLE);
                        mScrollVoter.setVisibility(View.INVISIBLE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
    }

    private int getSizeDP(int size) {
        Resources r = getContext().getResources();
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                size,
                r.getDisplayMetrics()
        );
    }

    private Map<String, Map<String, Object>> dataMap;
    private Map<String, List<String>> exmap;

    private void updateUI(FirebaseUser user, Context context) {
        if (user != null) {
            dataFire.getVotingRef().addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    final List<String> electionList = new ArrayList<>();
                    electionList.clear();
                    electionList.add("");
                    if (snapshot.exists()) {
                        dataMap = (Map) snapshot.getValue();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            electionList.add(dataSnapshot.getKey());
                        }
        try {

            Collections.sort(electionList);
            electionList.set(0, getActivity().getString(R.string.select_election));
            ArrayAdapter<String> adapter = new ArrayAdapter<>(context, R.layout.custome_spinner, electionList);
            adapter.setDropDownViewResource(R.layout.custome_spinner);
            mElectionSelector.setAdapter(adapter);

            exmap = new HashMap<>();
            for (int i = 0; i < electionList.size(); i++) {
                if (!electionList.get(i).equals(getActivity().getString(R.string.select_election))) {
                    dataFire.getVotingRef().child(electionList.get(i)).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    candidateList.add(dataSnapshot.getKey());
                                    votingMap.put(dataSnapshot.getKey(), (int) dataSnapshot.getChildrenCount());
                                }
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        }catch (Exception e){
            Log.e("Exception",e.getMessage());
        }
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }
    private void widget(View view) {
        mElectionSelector = (Spinner) view.findViewById(R.id.spnr_result_election);
        linearLayoutCandName = (LinearLayout) view.findViewById(R.id.layout_cand_name);
        mCandidateDetails = (LinearLayout) view.findViewById(R.id.layout_result_cand_details);
        mResultPieChart = (PieChart) view.findViewById(R.id.piechart);
        mWinner = (TextView) view.findViewById(R.id.txt_winner);
        mWinner.setVisibility(View.INVISIBLE);
        mDetailsText = (TextView) view.findViewById(R.id.txt_details_title);
        mDetailsText.setVisibility(View.INVISIBLE);

        mBottomPanel = (CardView) view.findViewById(R.id.bottom_winner_panel);
        mScrollVoter = (ScrollView) view.findViewById(R.id.scroll_voter);
        mBottomPanel.setVisibility(View.INVISIBLE);
        mScrollVoter.setVisibility(View.INVISIBLE);
    }
}