package com.pgames.evoting.fragment.voter;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pgames.evoting.R;

import org.w3c.dom.Text;

import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CandidateInfo#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CandidateInfo extends DialogFragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String ARG_NAME = "name";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";
    private static final String ARG_PROFILE_PIC = "profile";
    private static final String ARG_ABOUT = "about";
    private static final String ARG_ACHIEVEMENT = "achievements";
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private String mParamName;
    private String mParamDept;
    private String mParamYear;
    private String mParamProfile;
    private String mParamAbout;
    private String mParamAchievement;
    public CandidateInfo() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static CandidateInfo newInstance(AlertDialog.Builder builder) {
        CandidateInfo fragment = new CandidateInfo();
        fragment.mBuilder = builder;
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            mParamName = getArguments().getString(ARG_NAME);
            mParamDept = getArguments().getString(ARG_DEPT);
            mParamAbout = getArguments().getString(ARG_ABOUT);
            mParamYear = getArguments().getString(ARG_YEAR);
            mParamAchievement = getArguments().getString(ARG_ACHIEVEMENT);
            mParamProfile = getArguments().getString(ARG_PROFILE_PIC);
        }
    }

    private AlertDialog.Builder mBuilder;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.fragment_candidate_info, null);
        widget(view);
        setData();
        mBuilder.setView(view);
        return mBuilder.create();
    }

    private ImageView mProfilePhoto;
    private TextView mName;
    private TextView mDept;
    private TextView mYear;
    private TextView mAbout;
    private TextView mAchievement;
    private void widget(View view) {
    mProfilePhoto = (ImageView) view.findViewById(R.id.resultImage);
    mName = (TextView) view.findViewById(R.id.txt_candidate_name);
    mDept = (TextView) view.findViewById(R.id.txt_candidate_dept);
    mYear = (TextView) view.findViewById(R.id.txt_candidate_year);
    mAbout = (TextView) view.findViewById(R.id.txt_candidate_about);
    mAchievement = (TextView) view.findViewById(R.id.txt_candidate_achivements_details);
    }

    private void setData() {
        Glide.with(Objects.requireNonNull(getContext())).load(mParamProfile).into(mProfilePhoto);
        mName.setText(mParamName);
        mDept.setText(mParamDept);
        mYear.setText(mParamYear);
        mAbout.setText(mParamAbout);
        mAchievement.setText(mParamAchievement);
    }

}