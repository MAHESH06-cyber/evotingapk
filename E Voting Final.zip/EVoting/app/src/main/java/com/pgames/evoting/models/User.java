package com.pgames.evoting.models;

public class User {

    public String name;
    public String email;
    public boolean isAdmin;
    public String department;
    public String year;
    public String contact;
    public boolean isApproveVoter;
    public boolean isCandidate;
    public boolean isApproveCandidate;
    public boolean isRequestVoter;
    public boolean isRequestCandidate;
    public int deptIndex;
    public int yearIndex;
    public String btnSaveState;
    public String btnApplyCandState;
    public String profile;
    public User(String name, String email, boolean isAdmin, boolean isApproveVoter, boolean isCandidate, boolean isApproveCandidate) {
        this.name = name;
        this.email = email;
        this.isAdmin = isAdmin;
        this.isApproveVoter = isApproveVoter;
        this.isCandidate = isCandidate;
        this.isApproveCandidate = isApproveCandidate;
    }

    public User(String name, String email, boolean isAdmin, String department, String year, String contact, boolean isApproveVoter, boolean isCandidate, boolean isApproveCandidate, boolean isRequestVoter, boolean isRequestCandidate, int deptIndex, int yearIndex, String btnSaveState, String btnApplyCandState, String profile) {
        this.name = name;
        this.email = email;
        this.isAdmin = isAdmin;
        this.department = department;
        this.year = year;
        this.contact = contact;
        this.isApproveVoter = isApproveVoter;
        this.isCandidate = isCandidate;
        this.isApproveCandidate = isApproveCandidate;
        this.isRequestVoter = isRequestVoter;
        this.isRequestCandidate = isRequestCandidate;
        this.deptIndex = deptIndex;
        this.yearIndex = yearIndex;
        this.btnSaveState = btnSaveState;
        this.btnApplyCandState = btnApplyCandState;
        this.profile = profile;
    }
}
