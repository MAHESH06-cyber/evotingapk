package com.pgames.evoting.models;

import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class DataFire {
    private String userID;
    private FirebaseUser user;
    private FirebaseAuth mAuth;
    private DatabaseReference userRef, academicRef, voterReqRef, nomineeReqRef, voterRejectedRef, nomineeRejectedRef, approvedVoterRef, approvedCandRef;
    private DatabaseReference scheduleRef,electionDataRef,electionListRef,votingRef,userVotedRef,applyingRef;
    private FirebaseDatabase database;
    private StorageReference photoRef;
    private StorageReference storageRef;
    public DataFire() {
    }

    public DatabaseReference getApplyingRef() {
        applyingRef = getUserRef().child("devices");
        return applyingRef;
    }

    public DatabaseReference getUserVotedRef() {
        userVotedRef = getUserRef().child("voted");
        return userVotedRef;
    }

    public DatabaseReference getVotingRef() {
        votingRef = getDatabase().getReference().child("voting");
        return votingRef;
    }

    public DatabaseReference getElectionListRef() {
        electionListRef = getDatabase().getReference().child("election");
        return electionListRef;
    }

    public DatabaseReference getElectionDataRef() {
        electionDataRef = getUserRef().child("election");
        return electionDataRef;
    }

    public StorageReference getStorageRef() {
        storageRef =FirebaseStorage.getInstance().getReference();
        return storageRef;
    }

    public StorageReference getPhotoRef() {
         photoRef = storageRef.child("profile_photo").child(getUserID());
        return photoRef;
    }

    public DatabaseReference getScheduleRef() {
        scheduleRef = database.getReference().child("schedule");
        return scheduleRef;
    }

    public DatabaseReference getVoterRejectedRef() {
        voterRejectedRef = database.getReference().child("admin").child("rejectedVoter");
        return voterRejectedRef;
    }

    public DatabaseReference getNomineeRejectedRef() {
        nomineeRejectedRef = database.getReference().child("admin").child("rejectedNominee");
        return nomineeRejectedRef;
    }

    public DatabaseReference getApprovedVoterRef() {
        approvedVoterRef = database.getReference().child("admin").child("approvedVoter");
        return approvedVoterRef;
    }

    public DatabaseReference getApprovedCandRef() {
        approvedCandRef = database.getReference().child("admin").child("approvedCandidate");
        return approvedCandRef;
    }

    public DatabaseReference getVoterReqRef() {
        voterReqRef = database.getReference().child("admin").child("voter");
        return voterReqRef;
    }

    public DatabaseReference getNomineeReqRef() {
        nomineeReqRef = database.getReference().child("admin").child("nominee");
        return nomineeReqRef;
    }

    public DatabaseReference getAcademicRef() {
        academicRef = database.getReference().child("academic");
        return academicRef;
    }

    public DatabaseReference getUserRef() {
        userRef = database.getReference().child("users").child(getUserID());
        return userRef;
    }

    public FirebaseDatabase getDatabase() {
        database = FirebaseDatabase.getInstance();
        return database;
    }

    public String getUserID() {
        user = FirebaseAuth.getInstance().getCurrentUser();
        userID = user.getUid();
        return userID;
    }

    public FirebaseUser getUser() {
        user = FirebaseAuth.getInstance().getCurrentUser();
        return user;
    }

    public FirebaseAuth getmAuth() {
        mAuth = FirebaseAuth.getInstance();
        return mAuth;
    }
}
