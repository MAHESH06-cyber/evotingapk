package com.pgames.evoting.models;

public class VotingList {
    private String name;
    private String uid;
    private String year;
    private String department;
    private String photo;
    private String about;
    private String achievements;
    private String election;

    public VotingList() {
    }

    public VotingList(String name, String uid, String year, String department, String photo, String about, String achievements, String election) {
        this.name = name;
        this.uid = uid;
        this.year = year;
        this.department = department;
        this.photo = photo;
        this.about = about;
        this.achievements = achievements;
        this.election = election;
    }

    public String getName() {
        return name;
    }

    public String getUid() {
        return uid;
    }

    public String getYear() {
        return year;
    }

    public String getDepartment() {
        return department;
    }

    public String getPhoto() {
        return photo;
    }

    public String getAbout() {
        return about;
    }

    public String getAchievements() {
        return achievements;
    }

    public String getElection() {
        return election;
    }
}
