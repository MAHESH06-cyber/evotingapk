package com.pgames.evoting.fragment.admin;

import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toolbar;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.adapter.NominiesRequestAdapter;
import com.pgames.evoting.adapter.VoterRequestsAdapter;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.NominiesRequest;
import com.pgames.evoting.models.VoterRequests;

import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AdminNominiesRequest#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AdminNominiesRequest extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private DataFire dataFire;
    private NominiesRequestAdapter adapter;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private TextView mNomineeInfo;
    private RadioButton mPending, mRejected;
    private RadioGroup mRadioGroup;

    public AdminNominiesRequest() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AdminNominiesRequest.
     */
    // TODO: Rename and change types and number of parameters
    public static AdminNominiesRequest newInstance(String param1, String param2) {
        AdminNominiesRequest fragment = new AdminNominiesRequest();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }


        //Function while system back pressed called
        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (getActivity() != null)
                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new AdminHome());
            }
        };
        //calling onBackPressed callback
        requireActivity()
                .getOnBackPressedDispatcher()
                .addCallback(this, onBackPressedCallback);

        //firebase
        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_nominies_request, container, false);
        //initialize
        widget(view);

        loadRequests();
        listener();


        return view;
    }

    private void loadRequests() {
        FirebaseRecyclerOptions<NominiesRequest> options = new FirebaseRecyclerOptions.Builder<NominiesRequest>()
                .setQuery(dataFire.getNomineeReqRef(), NominiesRequest.class)
                .build();
        adapter = new NominiesRequestAdapter(options,getContext());
        recyclerView.setAdapter(adapter);
        dataFire.getNomineeReqRef().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    if (snapshot.exists()) {
                        mNomineeInfo.setVisibility(View.GONE);
                    } else {
                        mNomineeInfo.setText(getString(R.string.no_data_found));
                        mNomineeInfo.setVisibility(View.VISIBLE);
                    }
                } catch (IllegalStateException illegalStateException) {
                Log.e("NomineeRequest",illegalStateException.getMessage());
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void widget(View view) {
        //Setup toolbar
        Toolbar toolbar = view.findViewById(R.id.tool_nominies);
        TextView textView = view.findViewById(R.id.txt_toolbar_title);
        textView.setText(R.string.nominee);
        ImageView back = view.findViewById(R.id.img_btn_toolbar_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)Objects.requireNonNull(getActivity())).onBackPressed();
            }
        });

        recyclerView = view.findViewById(R.id.recycler_nominies);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        //textview
        mNomineeInfo = (TextView) view.findViewById(R.id.nominiee_info);

        //radio button
        mPending = (RadioButton) view.findViewById(R.id.rdb_pending_nominie);
        mRejected = (RadioButton) view.findViewById(R.id.rdb_rejected_nominie);

        //radio group
        mRadioGroup = (RadioGroup) view.findViewById(R.id.toggle);
    }
    public static boolean rejected = false;
    private void listener() {
        //pending
        mPending.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    rejected = false;
                    Log.e("Pending", String.valueOf(isChecked));
                    FirebaseRecyclerOptions<NominiesRequest> options = new FirebaseRecyclerOptions.Builder<NominiesRequest>()
                            .setQuery(dataFire.getNomineeReqRef(), NominiesRequest.class)
                            .build();
                    adapter.updateOptions(options);
                    dataFire.getNomineeReqRef().addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            try {
                                if (snapshot.exists()) {
                                    mNomineeInfo.setVisibility(View.GONE);
                                } else {
                                    mNomineeInfo.setText(getString(R.string.no_data_found));
                                    mNomineeInfo.setVisibility(View.VISIBLE);
                                }
                            }catch (IllegalStateException illegalStateException){
                                Log.e("NomineeRequest",illegalStateException.getMessage());
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }
            }
        });

        //rejected
        mRejected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    rejected = true;
                    Log.e("Rejected", String.valueOf(isChecked));
                    FirebaseRecyclerOptions<NominiesRequest> options = new FirebaseRecyclerOptions.Builder<NominiesRequest>()
                            .setQuery(dataFire.getNomineeRejectedRef(), NominiesRequest.class)
                            .build();
                    adapter.updateOptions(options);
                    dataFire.getNomineeRejectedRef().addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            try {
                                if (snapshot.exists()) {
                                    mNomineeInfo.setVisibility(View.GONE);
                                } else {
                                    mNomineeInfo.setText(getString(R.string.no_data_found_rejected));
                                    mNomineeInfo.setVisibility(View.VISIBLE);
                                }
                            }catch (IllegalStateException illegalStateException){
                                Log.e("NomineeRequest",illegalStateException.getMessage());
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}