package com.pgames.evoting.fragment.common;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.admin.AdminHome;
import com.pgames.evoting.fragment.candidate.CandidateProfile;
import com.pgames.evoting.fragment.voter.UpcommingElections;
import com.pgames.evoting.fragment.voter.VoterProfile;
import com.pgames.evoting.models.DataFire;

import java.util.Map;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Splash#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Splash extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private DataFire dataFire;

    public Splash() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Splash.
     */
    // TODO: Rename and change types and number of parameters
    public static Splash newInstance(String param1, String param2) {
        Splash fragment = new Splash();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onStart() {
        super.onStart();
//        updateUI(dataFire.getUser());
        checkUserStatus();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        dataFire = new DataFire();
        dataFire.getDatabase();
        dataFire.getmAuth();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_splash, container, false);
        //initialization
        widget(view);

        ((MainActivity)Objects.requireNonNull(getActivity())).hideBottomNavBar();
//        updateUI(dataFire.getUser());
    checkUserStatus();
        return view;
    }

    private void widget(View view) {

    }

    private static final String ARG_NAME = "name";
    private static final String ARG_EMAIL = "email";
    private static final String ARG_CONTACT = "contact";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";
    private static final String ARG_IS_ADMIN = "isAdmin";
    private static final String ARG_IS_APPROVE_VOTER = "isApproveVoter";
    private static final String ARG_IS_CANDIDATE = "isCandidate";
    private static final String ARG_IS_APPROVE_CANDIDATE = "isApproveCandidate";
    private static final String ARG_IS_REQUEST_VOTER = "isRequestVoter";
    private static final String ARG_IS_REQUEST_CANDIDATE = "isRequestCandidate";
    private static final String ARG_DEPT_INDEX = "deptIndex";
    private static final String ARG_YEAR_INDEX = "yearIndex";
    private static final String ARG_BTN_APPLY_CAND_STATE = "btnApplyCandState";
    private static final String ARG_BTN_SAVE_STATE = "btnSaveState";
    private static final String ARG_PROFILE_PIC = "profile";

    private void checkUserStatus(){
        if(dataFire.getUser()!=null)
        dataFire.getUserRef().child("status").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        if (snapshot.getValue().toString().equals("blocked")){
                            Log.e("User",snapshot.getValue().toString());
                            if (MainActivity.loggedIn==0)
                            Objects.requireNonNull(getActivity()).getSupportFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.main_host_fragment,new Blocked())
                                    .commit();
                        }else if(snapshot.getValue().toString().equals("active")) {
                        updateUI(dataFire.getUser());
                        }
                    }else {
                        updateUI(dataFire.getUser());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        else updateUI(dataFire.getUser());

    }

    private void updateUI(FirebaseUser user) {
        if (user != null)
        dataFire.getUserRef()
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists())
                            try {

                                FirebaseInstanceId.getInstance().getInstanceId()
                                        .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                                            @Override
                                            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                                if (!task.isSuccessful()) {
                                                    Log.e("Deveice Id", "getInstanceId failed", task.getException());
                                                    return;
                                                }
                                                // Get new Instance ID token
                                                String token = task.getResult().getToken();
                                                dataFire.getApplyingRef().child(token).setValue("registered");
                                                Log.e("Device Id",token);

                                            }
                                        });

                                Map<String, Map<String, Object>> userDataMap = (Map) snapshot.getValue();
                                Bundle bundle = new Bundle();
                                assert userDataMap != null;
                                bundle.putString(ARG_NAME, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_NAME));
                                bundle.putString(ARG_EMAIL, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_EMAIL));
                                bundle.putString(ARG_CONTACT, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_CONTACT));
                                bundle.putString(ARG_DEPT_INDEX, String.valueOf(Objects.requireNonNull(userDataMap.get("data")).get(ARG_DEPT_INDEX)));
                                bundle.putBoolean(ARG_IS_ADMIN, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_ADMIN));
                                bundle.putBoolean(ARG_IS_APPROVE_CANDIDATE, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_CANDIDATE));
                                bundle.putBoolean(ARG_IS_APPROVE_VOTER, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_VOTER));
                                bundle.putString(ARG_YEAR_INDEX, String.valueOf(Objects.requireNonNull(userDataMap.get("data")).get(ARG_YEAR_INDEX)));
                                bundle.putBoolean(ARG_IS_REQUEST_CANDIDATE, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_REQUEST_CANDIDATE));
                                bundle.putBoolean(ARG_IS_REQUEST_VOTER, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_REQUEST_VOTER));
                                bundle.putBoolean(ARG_IS_CANDIDATE, (boolean) Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_CANDIDATE));
                                if (snapshot.child("data").child(ARG_PROFILE_PIC).exists()) {
                                    bundle.putString(ARG_PROFILE_PIC, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_PROFILE_PIC));
                                } else bundle.putString(ARG_PROFILE_PIC, "");
                                if (snapshot.child("data").child(ARG_DEPT).exists())
                                    bundle.putString(ARG_DEPT, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_DEPT));
                                else bundle.putString(ARG_DEPT, "");
                                if (snapshot.child("data").child(ARG_YEAR).exists())
                                    bundle.putString(ARG_YEAR, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_YEAR));
                                else bundle.putString(ARG_YEAR, "");

                                if (snapshot.child("data").child(ARG_BTN_SAVE_STATE).exists())
                                    bundle.putString(ARG_BTN_SAVE_STATE, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_BTN_SAVE_STATE));
                                else bundle.putString(ARG_BTN_SAVE_STATE, (String) getText(R.string.save));

                                if (snapshot.child("data").child(ARG_BTN_APPLY_CAND_STATE).exists())
                                    bundle.putString(ARG_BTN_APPLY_CAND_STATE, (String) Objects.requireNonNull(userDataMap.get("data")).get(ARG_BTN_SAVE_STATE));
                                else bundle.putString(ARG_BTN_APPLY_CAND_STATE, (String) getText(R.string.candidate_apply));

                                if (snapshot.child("data").child(ARG_IS_ADMIN).exists())
                                if (Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_ADMIN), false)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_VOTER), false)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_CANDIDATE), false)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_CANDIDATE), false)) {
                                    VoterProfile voterProfile = new VoterProfile();
                                    voterProfile.setArguments(bundle);
                                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(voterProfile);
                                } else if (Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_ADMIN), false)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_VOTER), true)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_CANDIDATE), false)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_CANDIDATE), false))
                                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new UpcommingElections());
                                else if (Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_ADMIN), false)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_VOTER), true)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_CANDIDATE), false)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_CANDIDATE), true)) {
                                    //set profile pic
                                    CandidateProfile candidateProfile = new CandidateProfile();
                                    candidateProfile.setArguments(bundle);
                                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(candidateProfile);
                                } else if (Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_ADMIN), false)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_VOTER), true)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_APPROVE_CANDIDATE), true)
                                        && Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_CANDIDATE), true)) {

                                    //Set profile photo and other details
//                                    CandidateDetails candidateDetails = new CandidateDetails();
//                                    candidateDetails.setArguments(bundle);
                                    UpcommingElections upcommingElections = new UpcommingElections();
                                    upcommingElections.setArguments(bundle);
                                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(upcommingElections);
                                } else if (Objects.equals(Objects.requireNonNull(userDataMap.get("data")).get(ARG_IS_ADMIN), true))
                                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new AdminHome());
                                else
                                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new AdminHome());
                            } catch (Exception e) {
                                Log.e("SplashExp", e.getMessage());
                            }
                            else ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new AdminHome());

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Log.e("Login Database error", error.getMessage());
                        }
                    });
        else
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    //start login fragment
                    if (getActivity() != null)
                        ((MainActivity) getActivity()).startFragment(new Login());
                }
            }, 2000);

    }
}