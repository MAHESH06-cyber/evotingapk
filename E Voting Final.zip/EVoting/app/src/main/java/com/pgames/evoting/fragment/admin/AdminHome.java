package com.pgames.evoting.fragment.admin;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.common.Login;
import com.pgames.evoting.fragment.common.Results;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.utils.BottomNavigationBehavior;

import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AdminHome#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AdminHome extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private CardView mCrdVoter, mCrdSchedule, mCrdNominee, mCrdDepartment,mCrdApprVoter,mCrdApprNominee,mCrdResult,mCrdElection;
    private Button mSignOut;
    private DataFire dataFire;
    public AdminHome() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AdminHome.
     */
    // TODO: Rename and change types and number of parameters
    public static AdminHome newInstance(String param1, String param2) {
        AdminHome fragment = new AdminHome();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        dataFire = new DataFire();
        dataFire.getmAuth();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_home, container, false);
        //initialization
        widget(view);
        ((MainActivity)Objects.requireNonNull(getActivity())).hideBottomNavBar();
        listener();
        return view;
    }

    private void listener() {
        //Voter Request
        mCrdVoter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new AdminVotersRequest());
            }
        });

        //Candidate Request
        mCrdNominee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)Objects.requireNonNull(getActivity())).startFragment(new AdminNominiesRequest());
            }
        });

        //Schedule
        mCrdSchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)Objects.requireNonNull(getActivity())).startFragment(new AdminScheduleElection());
            }
        });

        //Manage Departments
        mCrdDepartment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).startFragment(new Departments());

            }
        });

        //voter list
        mCrdApprVoter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).startFragment(new ApprovedVoters());
            }
        });

        //Candidate list
        mCrdApprNominee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).startFragment(new ApprovedCandidates());
            }
        });

        //Result
        mCrdResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).startFragment(new GetResult());
            }
        });


        //sign out
        mSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //sign out admin
                dataFire.getmAuth().signOut();
                //load login screen
                ((MainActivity)Objects.requireNonNull(getActivity())).startFragment(new Login());
            }
        });

        //Election details
        mCrdElection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new ElectionDetails());
            }
        });
    }
    private static final String ARG_IS_ADMIN = "admin";
    private void widget(View view) {
        //CardView
        mCrdDepartment = (CardView) view.findViewById(R.id.crd_department);
        mCrdNominee = (CardView) view.findViewById(R.id.crd_nominee);
        mCrdSchedule = (CardView) view.findViewById(R.id.crd_schedule);
        mCrdVoter = (CardView) view.findViewById(R.id.crd_voters);
        mCrdApprNominee = (CardView) view.findViewById(R.id.crd_appr_nominee);
        mCrdApprVoter = (CardView) view.findViewById(R.id.crd_appr_voter);
        mCrdResult = (CardView) view.findViewById(R.id.crd_result);
        mCrdElection = (CardView) view.findViewById(R.id.crd_election);
        //Button
        mSignOut = (Button) view.findViewById(R.id.btn_admin_sign_out);

    }
}