package com.pgames.evoting.fragment.admin;

import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.adapter.ApprovedVoterAdapter;
import com.pgames.evoting.models.ApprovedVoter;
import com.pgames.evoting.models.DataFire;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ApprovedVoters#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ApprovedVoters extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private ApprovedVoterAdapter adapter;
    private DataFire dataFire ;
    public ApprovedVoters() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ApprovedVoters.
     */
    // TODO: Rename and change types and number of parameters
    public static ApprovedVoters newInstance(String param1, String param2) {
        ApprovedVoters fragment = new ApprovedVoters();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                ((MainActivity)getActivity()).startFragment(new AdminHome());
            }
        };
        getActivity().getOnBackPressedDispatcher().addCallback(onBackPressedCallback);

        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_approved_voters, container, false);
        widget(view);
        FirebaseRecyclerOptions<ApprovedVoter> options = new FirebaseRecyclerOptions.Builder<ApprovedVoter>()
                .setQuery(dataFire.getApprovedVoterRef(),ApprovedVoter.class)
                .build();

        adapter = new ApprovedVoterAdapter(options,getContext());
        recyclerView.setAdapter(adapter);
        return view;
    }

    private void widget(View view) {
    recyclerView = (RecyclerView) view.findViewById(R.id.rclr_appr_voter);
    layoutManager = new LinearLayoutManager(getContext());
    recyclerView.setLayoutManager(layoutManager);
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }
}