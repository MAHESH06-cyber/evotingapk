package com.pgames.evoting.models;

public class ApprovedVoter {
    private String name;
    private String uid;
    private String year;
    private String department;
    private String photo;
    private String status;
    public ApprovedVoter() {
    }

    public ApprovedVoter(String name, String uid, String year, String department, String photo, String status) {
        this.name = name;
        this.uid = uid;
        this.year = year;
        this.department = department;
        this.photo = photo;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
