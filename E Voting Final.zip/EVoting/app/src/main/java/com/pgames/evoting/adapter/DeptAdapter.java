package com.pgames.evoting.adapter;

public class DeptAdapter {

}
