package com.pgames.evoting.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.admin.AdminNominiesRequest;
import com.pgames.evoting.fragment.voter.CandidateInfo;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.NominiesRequest;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class NominiesRequestAdapter extends FirebaseRecyclerAdapter<NominiesRequest, NominiesRequestAdapter.ViewHolder> {


    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    private Context mContext;

    public NominiesRequestAdapter(@NonNull FirebaseRecyclerOptions<NominiesRequest> options, Context context) {
        super(options);
        mContext = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull NominiesRequest model) {
        try {

            holder.name.setText(model.getName());
            holder.department.setText(model.getDepartment());
            String year = "- " + model.getYear();
            holder.year.setText(year);

            Glide.with(mContext).load(model.getPhoto()).into(holder.photo);

            Map<String, String> userMap = new HashMap<>();
            userMap.put("name", model.getName());
            userMap.put("department", model.getDepartment());
            userMap.put("uid", model.getUid());
            userMap.put("photo", model.getPhoto());
            userMap.put("year", model.getYear());
            userMap.put("about", model.getAbout());
            userMap.put("election", model.getElection());
            userMap.put("achievements", model.getAchievements());

            if (AdminNominiesRequest.rejected) {
                //reject
                holder.reject.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DataFire dataFire = new DataFire();
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isApproveCandidate").setValue(false);
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isRejectedCandidate").setValue(true);

                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                        dataFire.getNomineeRejectedRef().child(itemRef.getKey()).setValue(userMap)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            itemRef.removeValue();
                                            final String myKeyItem = itemRef.getKey();
                                            assert myKeyItem != null;
                                            dataFire.getNomineeReqRef().child(myKeyItem).removeValue();
                                        }
                                    }
                                });

                    }
                });

                //accept
                holder.accept.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DataFire dataFire = new DataFire();
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isApproveCandidate").setValue(true);
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isCandidate").setValue(true);

                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                        dataFire.getElectionListRef().child(model.getElection()).child(itemRef.getKey()).setValue(userMap);
                        dataFire.getApprovedCandRef().child(itemRef.getKey()).setValue(userMap)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            itemRef.removeValue();
                                            final String myKeyItem = itemRef.getKey();
                                            assert myKeyItem != null;
                                            dataFire.getNomineeReqRef().child(myKeyItem).removeValue();
                                        }
                                    }
                                });

                    }
                });


                holder.photo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setTitle("Candidate Profile")
                                .setCancelable(false)
                                .setNegativeButton("Reject", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        DataFire dataFire = new DataFire();
                                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                                .child("data").child("isApproveCandidate").setValue(false);
                                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                                .child("data").child("isRejectedCandidate").setValue(true);

                                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                                        dataFire.getNomineeRejectedRef().child(itemRef.getKey()).setValue(userMap)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            itemRef.removeValue();
                                                            final String myKeyItem = itemRef.getKey();
                                                            assert myKeyItem != null;
                                                            dataFire.getNomineeReqRef().child(myKeyItem).removeValue();
                                                        }
                                                    }
                                                });

                                    }
                                })
                                .setPositiveButton("Approve", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        DataFire dataFire = new DataFire();
                                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                                .child("data").child("isApproveCandidate").setValue(true);
                                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                                .child("data").child("isCandidate").setValue(true);

                                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                                        dataFire.getElectionListRef().child(model.getElection()).child(itemRef.getKey()).setValue(userMap);
                                        dataFire.getApprovedCandRef().child(itemRef.getKey()).setValue(userMap)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            itemRef.removeValue();
                                                            final String myKeyItem = itemRef.getKey();
                                                            assert myKeyItem != null;
                                                            dataFire.getNomineeReqRef().child(myKeyItem).removeValue();
                                                        }
                                                    }
                                                });


                                    }
                                });
                        CandidateInfo candidateInfo = CandidateInfo.newInstance(builder);
                        Bundle bundle = new Bundle();
                        bundle.putString(ARG_NAME, model.getName());
                        bundle.putString(ARG_YEAR, model.getYear());
                        bundle.putString(ARG_DEPT, model.getDepartment());
                        bundle.putString(ARG_PROFILE_PIC, model.getPhoto());
                        bundle.putString(ARG_ABOUT, model.getAbout());
                        bundle.putString(ARG_ACHIEVEMENT, model.getAchievements());
                        candidateInfo.setArguments(bundle);
                        candidateInfo.setShowsDialog(true);
                        candidateInfo.show(((MainActivity) mContext).getSupportFragmentManager(), "Candidate Info");
                    }
                });


            } else {
                //reject
                holder.reject.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DataFire dataFire = new DataFire();
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isApproveCandidate").setValue(false);
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isRejectedCandidate").setValue(true);

                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                        dataFire.getNomineeRejectedRef().child(itemRef.getKey()).setValue(userMap)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            final String myKeyItem = itemRef.getKey();
                                            assert myKeyItem != null;
                                            dataFire.getNomineeReqRef().child(myKeyItem).removeValue();
                                        }
                                    }
                                });

                    }
                });

                //accept
                holder.accept.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DataFire dataFire = new DataFire();
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isApproveCandidate").setValue(true);
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isCandidate").setValue(true);

                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                        dataFire.getElectionListRef().child(model.getElection()).child(itemRef.getKey()).setValue(userMap);
                        dataFire.getApprovedCandRef().child(itemRef.getKey()).setValue(userMap)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            final String myKeyItem = itemRef.getKey();
                                            assert myKeyItem != null;
                                            dataFire.getNomineeReqRef().child(myKeyItem).removeValue();
                                        }
                                    }
                                });

                    }
                });


                holder.photo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setTitle("Candidate Profile")
                                .setCancelable(false)
                                .setNegativeButton("Reject", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        DataFire dataFire = new DataFire();
                                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                                .child("data").child("isApproveCandidate").setValue(false);
                                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                                .child("data").child("isRejectedCandidate").setValue(true);

                                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                                        dataFire.getNomineeRejectedRef().child(itemRef.getKey()).setValue(userMap)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            final String myKeyItem = itemRef.getKey();
                                                            assert myKeyItem != null;
                                                            dataFire.getNomineeReqRef().child(myKeyItem).removeValue();
                                                        }
                                                    }
                                                });


                                    }
                                })
                                .setPositiveButton("Approve", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        DataFire dataFire = new DataFire();
                                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                                .child("data").child("isApproveCandidate").setValue(true);
                                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                                .child("data").child("isCandidate").setValue(true);

                                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                                        dataFire.getElectionListRef().child(model.getElection()).child(itemRef.getKey()).setValue(userMap);
                                        dataFire.getApprovedCandRef().child(itemRef.getKey()).setValue(userMap)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            final String myKeyItem = itemRef.getKey();
                                                            assert myKeyItem != null;
                                                            dataFire.getNomineeReqRef().child(myKeyItem).removeValue();
                                                        }
                                                    }
                                                });

                                    }
                                });
                        CandidateInfo candidateInfo = CandidateInfo.newInstance(builder);
                        Bundle bundle = new Bundle();
                        bundle.putString(ARG_NAME, model.getName());
                        bundle.putString(ARG_YEAR, model.getYear());
                        bundle.putString(ARG_DEPT, model.getDepartment());
                        bundle.putString(ARG_PROFILE_PIC, model.getPhoto());
                        bundle.putString(ARG_ABOUT, model.getAbout());
                        bundle.putString(ARG_ACHIEVEMENT, model.getAchievements());
                        candidateInfo.setArguments(bundle);
                        candidateInfo.setShowsDialog(true);
                        candidateInfo.show(((MainActivity) mContext).getSupportFragmentManager(), "Candidate Info");
                    }
                });


            }
        } catch (Exception e) {
            Log.e("BindViewHolderNominee", e.getMessage());
        }

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custome_reqest, parent, false);
        return new NominiesRequestAdapter.ViewHolder(view);
    }

    private static final String ARG_NAME = "name";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";
    private static final String ARG_PROFILE_PIC = "profile";
    private static final String ARG_ABOUT = "about";
    private static final String ARG_ACHIEVEMENT = "achievements";

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView name;
        public TextView department;
        public TextView year;
        public ImageView photo;
        public TextView reject;
        public TextView accept;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.req_name);
            this.department = (TextView) view.findViewById(R.id.req_dept);
            this.year = (TextView) view.findViewById(R.id.req_year);
            this.photo = (ImageView) view.findViewById(R.id.req_photo);
            this.reject = (TextView) view.findViewById(R.id.req_reject);
            this.accept = (TextView) view.findViewById(R.id.req_accept);
        }
    }
}
