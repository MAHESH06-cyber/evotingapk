package com.pgames.evoting.fragment.voter;

import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pgames.evoting.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ScheduleShow#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ScheduleShow extends DialogFragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mES;
    private String mEE;
    private String mNS;
    private String mNE;

    public ScheduleShow() {
        // Required empty public constructor
    }

    public static ScheduleShow newInstance(AlertDialog.Builder builder) {
        ScheduleShow fragment = new ScheduleShow();
        fragment.mBuilder = builder;
        return fragment;
    }
    private AlertDialog.Builder mBuilder;
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.fragment_schedule_show, null);
        widget(view);
        mBuilder.setView(view);
        return mBuilder.create();
    }

    private void widget(View view) {
        TextView es = view.findViewById(R.id.es);
        TextView ee = view.findViewById(R.id.ee);
        TextView ns = view.findViewById(R.id.ns);
        TextView ne = view.findViewById(R.id.ne);
        es.setText(mES);
        ee.setText(mEE);
        ns.setText(mNS);
        ne.setText(mNE);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mES  = getArguments().getString("es");
            mEE  = getArguments().getString("ee");
            mNS  = getArguments().getString("ns");
            mNE  = getArguments().getString("ne");
        }
    }
}