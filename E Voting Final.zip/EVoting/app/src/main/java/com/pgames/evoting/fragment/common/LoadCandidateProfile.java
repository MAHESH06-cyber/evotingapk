package com.pgames.evoting.fragment.common;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;

import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.models.DataFire;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LoadCandidateProfile#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LoadCandidateProfile extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String ARG_NAME = "name";
    private static final String ARG_EMAIL = "email";
    private static final String ARG_CONTACT = "contact";
    private static final String ARG_YEAR = "year";
    private static final String ARG_DEPT = "department";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private String mParamName;
    private String mParamContact;
    private String mParamEmail;
    private String mParamDept;
    private String mParamYear;

    private TextInputEditText mName, mContactNumber, mEmail;
    private Spinner mDepartment, mYear;
    private Button mEdit, mSignOut;
    private ImageView mImgClose, mImgSave;

    public LoadCandidateProfile() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment LoadCandidateProfile.
     */
    // TODO: Rename and change types and number of parameters
    public static LoadCandidateProfile newInstance(String param1, String param2) {
        LoadCandidateProfile fragment = new LoadCandidateProfile();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            mParamName = getArguments().getString(ARG_NAME);
            mParamEmail = getArguments().getString(ARG_EMAIL);
            mParamContact = getArguments().getString(ARG_CONTACT);
            mParamYear = getArguments().getString(ARG_YEAR);
            mParamDept = getArguments().getString(ARG_DEPT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_load_candidate_profile, container, false);
        //initialize
        widget(view);
        listner();
        setDataUI();
        return view;
    }
    private static void deleteCache(Context context) {
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) { e.printStackTrace();}
    }

    private static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if(dir!= null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }

    private void listner() {
    mSignOut.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            DataFire dataFire = new DataFire();
            dataFire.getmAuth().signOut();
            deleteCache(getContext());
            ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new Login());
        }
    });

    mEdit.setVisibility(View.GONE);
    mEdit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            disableUI(false);
        }
    });
    }

    private void widget(View view) {
        //EditText
        mEmail = (TextInputEditText) view.findViewById(R.id.edt_voter_email_final);
        mEmail.setEnabled(false);
        mContactNumber = (TextInputEditText) view.findViewById(R.id.edt_voter_contact_number_final);
        mName = (TextInputEditText) view.findViewById(R.id.edt_voter_name_final);

        //Spinner
        mDepartment = (Spinner) view.findViewById(R.id.spnr_voter_dept);
        mYear = (Spinner) view.findViewById(R.id.spnr_voter_year);

        //Button
        mEdit = (Button) view.findViewById(R.id.btn_voter_save);
        mSignOut = (Button) view.findViewById(R.id.voter_sign_out);
        //ImageView
//        mImgClose = (ImageView) view.findViewById(R.id.img_btn_toolbar_close);
//        mImgSave = (ImageView) view.findViewById(R.id.img_btn_toolbar_save);

    }

    private void setDataUI() {
        //Set values
        try {
            mName.setText(mParamName);
            mEmail.setText(mParamEmail);
            final List<String> department = new ArrayList<>();
            final List<String> year = new ArrayList<>();
            department.add(mParamDept);
            year.add(mParamYear);
            ArrayAdapter<String> deptAdapter = new ArrayAdapter<>(getContext(), R.layout.custome_spinner, department);
            ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(getContext(), R.layout.custome_spinner, year);
            mDepartment.setAdapter(deptAdapter);
            mYear.setAdapter(yearAdapter);
            mContactNumber.setText(mParamContact);
            mEdit.setText(getText(R.string.edit_profile));
            disableUI(true);
        } catch (Exception e) {
            Log.e("ProfileExp", e.getMessage());
        }
    }

    private void disableUI(boolean check) {
        if (check) {
            mName.setEnabled(false);
            mContactNumber.setEnabled(false);
            mDepartment.setEnabled(false);
            mYear.setEnabled(false);
        } else {
            mName.setEnabled(true);
            mContactNumber.setEnabled(true);
            mDepartment.setEnabled(true);
            mYear.setEnabled(true);
        }
    }

}