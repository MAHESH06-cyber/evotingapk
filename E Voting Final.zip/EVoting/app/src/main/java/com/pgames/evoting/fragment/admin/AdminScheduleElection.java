package com.pgames.evoting.fragment.admin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.menu.ActionMenuItem;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.MainActivity;
import com.pgames.evoting.R;
import com.pgames.evoting.adapter.ScheduleAdapter;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.Schedule;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AdminScheduleElection#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AdminScheduleElection extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private final static String ARG_TITLE = "title";
    private final static String ARG_START_DATE_ELECTION = "startDateElection";
    private final static String ARG_END_DATE_ELECTION = "endDateElection";
    private final static String ARG_START_DATE_NOMINATION = "startDateNomination";
    private final static String ARG_END_DATE_NOMINATION = "endDateNomination";
    private final static String ARG_ACTION_EDIT_KEY = "edit";
    private final static String ARG_UPDATE_ACTION = "update";
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private String mParamTitle, mParamStartElection, mParamEndElection, mParamStartNomination, mParamEndNomination, mParamEditKey;
    private String mParamUpdate = "nonupdate";
    private TextInputEditText mTitle, mElectionFrom, mElectionTo, mNomineeFrom, mNomineeTo;

    private Button mSubmit;
    private DataFire dataFire;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private ScheduleAdapter adapter;
    private Query query;
    private RequestQueue mRequestQueue;
    private int mYear,mMonth,mDay;
    public AdminScheduleElection() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AdminScheduleElection.
     */
    // TODO: Rename and change types and number of parameters
    public static AdminScheduleElection newInstance(String param1, String param2) {
        AdminScheduleElection fragment = new AdminScheduleElection();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            mParamTitle = getArguments().getString(ARG_TITLE);
            mParamStartElection = getArguments().getString(ARG_START_DATE_ELECTION);
            mParamEndElection = getArguments().getString(ARG_END_DATE_ELECTION);
            mParamStartNomination = getArguments().getString(ARG_START_DATE_NOMINATION);
            mParamEndNomination = getArguments().getString(ARG_END_DATE_NOMINATION);
            mParamEditKey = getArguments().getString(ARG_ACTION_EDIT_KEY);
            mParamUpdate = getArguments().getString(ARG_UPDATE_ACTION);
        }

        //Function while system back pressed called
        OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (getActivity() != null)
                    ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new AdminHome());
            }
        };
        //calling onBackPressed callback
        requireActivity()
                .getOnBackPressedDispatcher()
                .addCallback(this, onBackPressedCallback);

        dataFire = new DataFire();
        dataFire.getmAuth();
        dataFire.getDatabase();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_schedule_election, container, false);
        //initialize
        widget(view);
        listener();

        query = dataFire.getScheduleRef();
        FirebaseRecyclerOptions<Schedule> options = new FirebaseRecyclerOptions.Builder<Schedule>()
                .setQuery(query, Schedule.class)
                .build();
        adapter = new ScheduleAdapter(options, getContext());
        recyclerView.setAdapter(adapter);

        List<String> values = new ArrayList<>();
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        if (!values.contains(String.valueOf(dataSnapshot.child(ARG_TITLE)))) {
                            values.add(String.valueOf(dataSnapshot.child(ARG_TITLE)));
                            Log.e("Title", String.valueOf(dataSnapshot.child(ARG_TITLE).getValue()));
                        }else {
                            Log.e("Repeat",dataSnapshot.getKey() +String.valueOf(dataSnapshot.child(ARG_TITLE).getValue()));
                            values.clear();
                            dataFire.getScheduleRef().child(Objects.requireNonNull(dataSnapshot.getKey())).removeValue();
              try {
                  AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                  builder.setMessage("Election title does not same\n"+String.valueOf(dataSnapshot.child(ARG_TITLE).getValue())+" election already existed"+"\nPlease consider another better one!")
                          .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                              @Override
                              public void onClick(DialogInterface dialog, int which) {
                                  dialog.dismiss();
                              }
                          }).create().show();
              }catch (NullPointerException e){
                  Log.e("Null Exp",e.getMessage());
              }
              }


                    }
                    values.clear();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        return view;
    }

    private void widget(View view) {
        //Setup toolbar
        Toolbar toolbar = view.findViewById(R.id.tool_nominies);
        TextView textView = view.findViewById(R.id.txt_toolbar_title);
        textView.setText(R.string.schedule_text);
        ImageView back = view.findViewById(R.id.img_btn_toolbar_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) Objects.requireNonNull(getActivity())).onBackPressed();
            }
        });

        getdata();
        //EditText
        mTitle = (TextInputEditText) view.findViewById(R.id.edt_title);
        mElectionTo = (TextInputEditText) view.findViewById(R.id.edt_election_to);
        mElectionFrom = (TextInputEditText) view.findViewById(R.id.edt_election_from);
        mNomineeFrom = (TextInputEditText) view.findViewById(R.id.edt_nominee_from);
        mNomineeTo = (TextInputEditText) view.findViewById(R.id.edt_nominee_to);
        mNomineeTo.setEnabled(false);
        //recycler view
        recyclerView = (RecyclerView) view.findViewById(R.id.schedule_recycler);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        //Button
        mSubmit = (Button) view.findViewById(R.id.btn_schedule_submit);
    }
    public void getdata(){
        Response.Listener<String> response_listener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Log.e("Response",response);
                    // JSONArray jsonArray = new JSONArray(response);
                    String object = new JSONObject(response).getString("datetime");


                    //JSONObject jsonObject = jsonArray.getJSONObject(0);
                    //Log.e("date", String.valueOf(jsonObject.getString("abbreviation")));
//                    Toast.makeText(mContext, object, Toast.LENGTH_SHORT).show();

                    String formatDate = object.substring(0,Math.min(object.length(),10));
                    String year = formatDate.substring(0,Math.min(formatDate.length(),4));
                    String month = formatDate.substring(5,Math.min(formatDate.length(),7));
                    String day = formatDate.substring(8,Math.min(formatDate.length(),10));
                    String finalDate = day+"/"+month+"/"+year;

                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.e("Exp",e.getMessage());
                }
            }
        };


        Response.ErrorListener response_error_listener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                try {
                    if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                        Log.e("TimeError",error.getMessage());
                    } else if (error instanceof AuthFailureError) {
                        //TODO
                        Log.e("AuthFail",error.getMessage());
                    } else if (error instanceof ServerError) {
                        //TODO
                        Log.e("Server",error.getMessage());
                    } else if (error instanceof NetworkError) {
                        //TODO
                        Log.e("NetworkFail",error.getMessage());
                    } else if (error instanceof ParseError) {
                        //TODO
                        Log.e("ParseFail",error.getMessage());
                    }
                }catch (Exception e){
                    Log.e("Response",e.getMessage());
                }

            }
        };

        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://worldtimeapi.org/api/timezone/Asia/Kolkata",response_listener,response_error_listener);
        getRequestQueue().add(stringRequest);
    }

    public RequestQueue getRequestQueue() {
        //requestQueue is used to stack your request and handles your cache.
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getContext());
        }
        return mRequestQueue;
    }
    private void hideKeyboard(View view) {
        try {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    private void listener() {
        //set update values
        try {
            if (mParamUpdate.equals(ARG_UPDATE_ACTION)) {
                mTitle.setText(mParamTitle);
                mElectionFrom.setText(mParamStartElection);
                mElectionTo.setText(mParamEndElection);
                mNomineeFrom.setText(mParamStartNomination);
                mNomineeTo.setText(mParamEndNomination);
                mSubmit.setText(getString(R.string.update));
            }
        } catch (NullPointerException pointerException) {
            Log.e("NullPointerUpdate", pointerException.getMessage());
        }
        mElectionFrom.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    hideKeyboard(v);
                    mElectionFrom.setShowSoftInputOnFocus(false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    DatePicker datePicker = new DatePicker(getContext());
                    datePicker.setMinDate(System.currentTimeMillis() - 1000);
                    datePicker.setCalendarViewShown(true);
                    datePicker.setSpinnersShown(true);
                    builder.setTitle("Election Start Date")
                            .setView(datePicker)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Log.e("Day", String.valueOf(datePicker.getDayOfMonth()));
                                    Log.e("Month", String.valueOf(datePicker.getMonth()));
                                    Log.e("Year", String.valueOf(datePicker.getYear()));
                                    String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();
                                    mElectionFrom.setText(date);
                                    mNomineeTo.setText(date);
                                    mNomineeTo.setEnabled(false);
                                    mElectionFrom.setFocusableInTouchMode(false);
                                    mElectionFrom.setFocusable(false);
                                    mElectionFrom.setFocusableInTouchMode(true);
                                    mElectionFrom.setFocusable(true);
                                    hideKeyboard(v);
                                }
                            })
                            .setCancelable(false)
                            .create()
                            .show();
                }
            }
        });

//        mElectionFrom.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mElectionFrom.setShowSoftInputOnFocus(false);
//                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
//                DatePicker datePicker = new DatePicker(getContext());
//                datePicker.setCalendarViewShown(true);
//                datePicker.setSpinnersShown(true);
//                builder.setTitle("Election Start Date")
//                        .setView(datePicker)
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                Log.e("Day", String.valueOf(datePicker.getDayOfMonth()));
//                                Log.e("Month", String.valueOf(datePicker.getMonth()));
//                                Log.e("Year", String.valueOf(datePicker.getYear()));
//                                String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();
//                                mElectionFrom.setText(date);
//                            }
//                        })
//                        .setCancelable(false)
//                        .create()
//                        .show();
//            }
//        });

        mElectionTo.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    hideKeyboard(v);
                    mElectionTo.setShowSoftInputOnFocus(false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    DatePicker datePicker = new DatePicker(getContext());
                    datePicker.setMinDate(System.currentTimeMillis() - 1000);
                    datePicker.setCalendarViewShown(true);
                    datePicker.setSpinnersShown(true);
                    builder.setTitle("Election End Date")
                            .setView(datePicker)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Log.e("Day", String.valueOf(datePicker.getDayOfMonth()));
                                    Log.e("Month", String.valueOf(datePicker.getMonth()));
                                    Log.e("Year", String.valueOf(datePicker.getYear()));
                                    String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();
                                    mElectionTo.setText(date);
                                    mElectionTo.setFocusableInTouchMode(false);
                                    mElectionTo.setFocusable(false);
                                    mElectionTo.setFocusableInTouchMode(true);
                                    mElectionTo.setFocusable(true);
                                    hideKeyboard(v);
                                }
                            })
                            .setCancelable(false)
                            .create()
                            .show();
                }
            }
        });

//        mElectionTo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mElectionTo.setShowSoftInputOnFocus(false);
//                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
//                DatePicker datePicker = new DatePicker(getContext());
//                datePicker.setCalendarViewShown(true);
//                datePicker.setSpinnersShown(true);
//                builder.setTitle("Election End Date")
//                        .setView(datePicker)
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                Log.e("Day", String.valueOf(datePicker.getDayOfMonth()));
//                                Log.e("Month", String.valueOf(datePicker.getMonth()));
//                                Log.e("Year", String.valueOf(datePicker.getYear()));
//                                String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();
//                                mElectionTo.setText(date);
//                            }
//                        })
//                        .setCancelable(false)
//                        .create()
//                        .show();
//            }
//        });
        mNomineeTo.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    hideKeyboard(v);
                    mNomineeTo.setShowSoftInputOnFocus(false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    DatePicker datePicker = new DatePicker(getContext());
                    datePicker.setMinDate(System.currentTimeMillis() - 1000);
                    datePicker.setSpinnersShown(true);
                    builder.setTitle("Nomination End Date")
                            .setView(datePicker)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Log.e("Day", String.valueOf(datePicker.getDayOfMonth()));
                                    Log.e("Month", String.valueOf(datePicker.getMonth()));
                                    Log.e("Year", String.valueOf(datePicker.getYear()));
                                    String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();
                                    mNomineeTo.setText(date);
                                    mNomineeTo.setFocusableInTouchMode(false);
                                    mNomineeTo.setFocusable(false);
                                    mNomineeTo.setFocusableInTouchMode(true);
                                    mNomineeTo.setFocusable(true);
                                    hideKeyboard(v);
                                }
                            })
                            .setCancelable(false)
                            .create()
                            .show();
                }
            }
        });
//        mNomineeTo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mNomineeTo.setShowSoftInputOnFocus(false);
//                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
//                DatePicker datePicker = new DatePicker(getContext());
//                datePicker.setSpinnersShown(true);
//                builder.setTitle("Nomination End Date")
//                        .setView(datePicker)
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                Log.e("Day", String.valueOf(datePicker.getDayOfMonth()));
//                                Log.e("Month", String.valueOf(datePicker.getMonth()));
//                                Log.e("Year", String.valueOf(datePicker.getYear()));
//                                String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();
//                                mNomineeTo.setText(date);
//                            }
//                        })
//                        .setCancelable(false)
//                        .create()
//                        .show();
//            }
//        });

        mNomineeFrom.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    hideKeyboard(v);
                    mNomineeFrom.setShowSoftInputOnFocus(false);
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    DatePicker datePicker = new DatePicker(getContext());
                    datePicker.setMinDate(System.currentTimeMillis() - 1000);
                    datePicker.setCalendarViewShown(true);
                    datePicker.setSpinnersShown(true);
                    builder.setTitle("Nomination Start Date")
                            .setView(datePicker)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Log.e("Day", String.valueOf(datePicker.getDayOfMonth()));
                                    Log.e("Month", String.valueOf(datePicker.getMonth()));
                                    Log.e("Year", String.valueOf(datePicker.getYear()));
                                    String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();
                                    mNomineeFrom.setText(date);
                                    mNomineeFrom.setFocusableInTouchMode(false);
                                    mNomineeFrom.setFocusable(false);
                                    mNomineeFrom.setFocusableInTouchMode(true);
                                    mNomineeFrom.setFocusable(true);
                                    hideKeyboard(v);
                                }
                            })
                            .setCancelable(false)
                            .create()
                            .show();
                }
            }
        });
//        mNomineeFrom.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mNomineeFrom.setShowSoftInputOnFocus(false);
//                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
//                DatePicker datePicker = new DatePicker(getContext());
//                datePicker.setCalendarViewShown(true);
//                datePicker.setSpinnersShown(true);
//                builder.setTitle("Nomination Start Date")
//                        .setView(datePicker)
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                Log.e("Day", String.valueOf(datePicker.getDayOfMonth()));
//                                Log.e("Month", String.valueOf(datePicker.getMonth()));
//                                Log.e("Year", String.valueOf(datePicker.getYear()));
//                                String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();
//                                mNomineeFrom.setText(date);
//                            }
//                        })
//                        .setCancelable(false)
//                        .create()
//                        .show();
//            }
//        });


        //Submit
        mSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                try {
                    Date eleStartdate = format.parse(mElectionFrom.getText().toString());
                    Date nomStartdate = format.parse(mNomineeFrom.getText().toString());
                    Date eleEnddate = format.parse(mElectionTo.getText().toString());
                    Date nomEnddate = format.parse(mNomineeTo.getText().toString());
                    if (Objects.requireNonNull(mTitle.getText()).toString().isEmpty())
                        Toast.makeText(getContext(), "Enter Title", Toast.LENGTH_SHORT).show();//mTitle.setError("Enter title");
                    else if (mElectionFrom.getText().toString().isEmpty())
                        mElectionFrom.setError("set valid date");
                    else if (mElectionTo.getText().toString().isEmpty())
                        mElectionTo.setError("set valid date");
                    else if (mNomineeFrom.getText().toString().isEmpty())
                        mNomineeFrom.setError("set valid date");
                    else if (mNomineeTo.getText().toString().isEmpty())
                        mNomineeTo.setError("set valid date");
                    else if (eleEnddate.before(eleStartdate)) {
                        Toast.makeText(getContext(), "Set valid election date", Toast.LENGTH_SHORT).show();
                    } else if (nomEnddate.before(nomStartdate)) {
                        Toast.makeText(getContext(), "Set valid nomination date", Toast.LENGTH_SHORT).show();
                    } else {
                        mNomineeTo.setError(null);
                        mElectionFrom.setError(null);
                        mElectionTo.setError(null);
                        mNomineeFrom.setError(null);
                        mTitle.setError(null);


                        mSubmit.setEnabled(false);
                        Map<String, String> scheduleMap = new HashMap<>();
                        scheduleMap.put(ARG_TITLE, mTitle.getText().toString());
                        scheduleMap.put(ARG_START_DATE_ELECTION, mElectionFrom.getText().toString());
                        scheduleMap.put(ARG_END_DATE_ELECTION, mElectionTo.getText().toString());
                        scheduleMap.put(ARG_START_DATE_NOMINATION, mNomineeFrom.getText().toString());
                        scheduleMap.put(ARG_END_DATE_NOMINATION, mNomineeTo.getText().toString());

                        if (mSubmit.getText().equals(getString(R.string.submit))) {
                            dataFire.getScheduleRef()
                                    .child(Objects.requireNonNull(dataFire.getScheduleRef().push().getKey()))
                                    .setValue(scheduleMap)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            mTitle.setText(null);
                                            mElectionFrom.setText(null);
                                            mElectionTo.setText(null);
                                            mNomineeFrom.setText(null);
                                            mNomineeTo.setText(null);
                                            mSubmit.setEnabled(true);
                                            mSubmit.setText(getString(R.string.submit));
                                        }
                                    });
                        } else if (mParamUpdate.equals(ARG_UPDATE_ACTION) || mSubmit.getText().equals(getString(R.string.update))) {
                            dataFire.getScheduleRef()
                                    .child(mParamEditKey)
                                    .setValue(scheduleMap)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            ((MainActivity) Objects.requireNonNull(getActivity())).startFragment(new AdminScheduleElection());

                                        }
                                    });
                        }
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }
}