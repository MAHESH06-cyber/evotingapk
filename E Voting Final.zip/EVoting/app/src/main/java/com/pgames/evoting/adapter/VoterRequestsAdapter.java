package com.pgames.evoting.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.Engine;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.pgames.evoting.R;
import com.pgames.evoting.fragment.admin.AdminVotersRequest;
import com.pgames.evoting.models.DataFire;
import com.pgames.evoting.models.VoterRequests;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class VoterRequestsAdapter extends FirebaseRecyclerAdapter<VoterRequests, VoterRequestsAdapter.ViewHolder> {

    /**
     * Initialize a {@link RecyclerView.Adapter} that listens to a Firebase query. See
     * {@link FirebaseRecyclerOptions} for configuration options.
     *
     * @param options
     */
    private Context mContext;

    public VoterRequestsAdapter(@NonNull FirebaseRecyclerOptions<VoterRequests> options, Context context) {
        super(options);
        mContext = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull VoterRequests model) {
        try {
//            holder.photo.setText(model.getPhoto());
            holder.name.setText(model.getName());
            holder.department.setText(model.getDepartment());
            String year = "- " + model.getYear();
            holder.year.setText(year);
            Log.e("Photo", model.getPhoto());
            Glide.with(mContext).load(model.getPhoto()).into(holder.photo);

            Map<String, String> userMap = new HashMap<>();
            userMap.put("name", model.getName());
            userMap.put("department", model.getDepartment());
            userMap.put("uid", model.getUid());
            userMap.put("photo", model.getPhoto());
            userMap.put("year", model.getYear());
            if (AdminVotersRequest.rejected) {
                Log.e("Voter","true");
                holder.reject.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DataFire dataFire = new DataFire();
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isApproveVoter").setValue(false);
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isRejected").setValue(true);

                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                        dataFire.getVoterRejectedRef().child(itemRef.getKey()).setValue(userMap)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            itemRef.removeValue();
                                            final String myKeyItem = itemRef.getKey();
                                            assert myKeyItem != null;
                                            dataFire.getVoterReqRef().child(myKeyItem).removeValue();
                                        }
                                    }
                                });

                    }

                });

                //accept
                holder.accept.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DataFire dataFire = new DataFire();
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isApproveVoter").setValue(true);

                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                        dataFire.getDatabase().getReference().child("users").child(model.getUid()).child("status").setValue("active");
                        dataFire.getApprovedVoterRef().child(itemRef.getKey()).setValue(userMap)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            itemRef.removeValue();
                                            final String myKeyItem = itemRef.getKey();
                                            assert myKeyItem != null;
                                            dataFire.getVoterReqRef().child(myKeyItem).removeValue();
                                        }
                                    }
                                });

                    }
                });
            }else {
                //reject
                holder.reject.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DataFire dataFire = new DataFire();
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isApproveVoter").setValue(false);
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isRejected").setValue(true);

                            DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                            dataFire.getVoterRejectedRef().child(itemRef.getKey()).setValue(userMap)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                final String myKeyItem = itemRef.getKey();
                                                assert myKeyItem != null;
                                                dataFire.getVoterReqRef().child(myKeyItem).removeValue();
                                            }
                                        }
                                    });

                        }

                });

                //accept
                holder.accept.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DataFire dataFire = new DataFire();
                        dataFire.getDatabase().getReference().child("users").child(model.getUid())
                                .child("data").child("isApproveVoter").setValue(true);

                        DatabaseReference itemRef = getRef(holder.getAdapterPosition());
                        dataFire.getApprovedVoterRef().child(itemRef.getKey()).setValue(userMap)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            final String myKeyItem = itemRef.getKey();
                                            assert myKeyItem != null;
                                            dataFire.getVoterReqRef().child(myKeyItem).removeValue();
                                        }
                                    }
                                });

                    }
                });

            }
        } catch (Exception e) {
            Log.e("BindViewHolder", e.getMessage());
        }

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custome_reqest, parent, false);
        return new ViewHolder(view);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView name;
        public TextView department;
        public TextView year;
        public ImageView photo;
        public TextView reject;
        public TextView accept;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.name = (TextView) view.findViewById(R.id.req_name);
            this.department = (TextView) view.findViewById(R.id.req_dept);
            this.year = (TextView) view.findViewById(R.id.req_year);
            this.photo = (ImageView) view.findViewById(R.id.req_photo);
            this.reject = (TextView) view.findViewById(R.id.req_reject);
            this.accept = (TextView) view.findViewById(R.id.req_accept);
        }
    }
}
