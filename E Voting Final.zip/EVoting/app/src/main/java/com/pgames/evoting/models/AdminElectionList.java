package com.pgames.evoting.models;

public class AdminElectionList {
    private String title;
    private String startDateElection;
    private String endDateElection;
    private String startDateNomination;
    private String endDateNomination;

    public AdminElectionList(String title, String startDateElection, String endDateElection, String startDateNomination, String endDateNomination) {
        this.title = title;
        this.startDateElection = startDateElection;
        this.endDateElection = endDateElection;
        this.startDateNomination = startDateNomination;
        this.endDateNomination = endDateNomination;
    }

    public AdminElectionList() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStartDateElection() {
        return startDateElection;
    }

    public void setStartDateElection(String startDateElection) {
        this.startDateElection = startDateElection;
    }

    public String getEndDateElection() {
        return endDateElection;
    }

    public void setEndDateElection(String endDateElection) {
        this.endDateElection = endDateElection;
    }

    public String getStartDateNomination() {
        return startDateNomination;
    }

    public void setStartDateNomination(String startDateNomination) {
        this.startDateNomination = startDateNomination;
    }

    public String getEndDateNomination() {
        return endDateNomination;
    }

    public void setEndDateNomination(String endDateNomination) {
        this.endDateNomination = endDateNomination;
    }
}
